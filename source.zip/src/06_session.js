/* ===== SESIÓN DE PREGUNTAS ===== */
let SE=null;
function checkType(q,val){const u=nfc(val),un=norm(val);if(!un)return{ok:false};
  const alts=q.alts||[q.ans];
  for(const a of alts){if(nfc(a)===u)return{ok:true}}
  for(const a of alts){if(norm(a)===un)return{ok:true,note:'Ojo con el acento o el apóstrofo: se escribe «'+a+'».'}}
  const na=x=>norm(x).replace(/'/g,'');for(const a of alts){if(na(a)===na(val))return{ok:true,note:'Ojo con el apóstrofo: se escribe «'+a+'».'}}
  return{ok:false}}
function startSession(qs,o){qs=qs.filter(Boolean);if(!qs.length){toast('No hay preguntas');return}
  SE={qs:qs.slice(),i:0,ok:0,tot:0,combo:0,max:0,xp:0,o:o||{},blk:{},lastOk:false};
  document.body.classList.add('in-session');window.scrollTo(0,0);showQ()}
function qHead(q){const total=SE.o.total||SE.qs.length;return'<div class="qtop"><button class="x" data-a="quit" aria-label="Salir">✕</button><div class="prog"><i style="width:'+Math.round(SE.i/total*100)+'%"></i></div><div class="combo">'+(SE.combo>1?'×'+SE.combo:'')+'</div></div>'+'<div class="qkind">'+esc(q.kind||'')+' · '+(SE.i+1)+'/'+total+'</div>'}
function showQ(){const q=SE.qs[SE.i];if(!q)return endSession();const A=$('#app');SE.cur=q;SE.locked=false;
  let h=qHead(q);
  if(q.k==='flash'){h+='<div class="flash" id="fl" data-a="flip" tabindex="0" role="button"><div class="big">'+(q.em||'')+'</div><div class="ca">'+esc(q.ca)+'</div><div class="bk" id="bk" hidden>'+esc(q.es)+'</div><small id="fh">Toca para ver el significado</small></div><div class="row" style="margin-top:12px;justify-content:center">'+spk(q.ca)+'</div><div class="fb" id="fbb" hidden><button class="btn sec" data-a="fno">Todavía no</button><button class="btn" data-a="fyes">Lo sabía</button></div>';
    A.innerHTML=h;setTimeout(()=>say(q.ca),150);return}
  if(q.k==='build'){h+='<div class="prompt">'+esc(q.es)+'</div><p class="muted">Ordena las palabras en inglés.</p><div class="line" id="ln"></div><div class="bank" id="bk">'+shuf(q.tok.concat(q.extra||[]).map((w,i)=>({w:w,i:i}))).map(o=>'<button class="wt" data-a="wt" data-v="'+o.i+'">'+esc(o.w)+'</button>').join('')+'</div><button class="btn block" id="ck" data-a="check" disabled>Comprobar</button>';
    SE.line=[];A.innerHTML=h+'<div class="spacer"></div>';return}
  if(q.k==='speak'){h+=speakHtml(q);SE.listening=false;A.innerHTML=h+'<div class="spacer"></div>';return}
  const sayBtn=q.say?'<button class="spk" data-a="say" data-v="'+esc(q.say)+'" data-r="'+(q.rate||'')+'" aria-label="Escuchar">🔊</button><button class="spk" data-a="slow" data-v="'+esc(q.say)+'" aria-label="Escuchar despacio">🐢</button>':'';
  h+='<div class="prompt">'+(q.em?'<span class="big">'+q.em+'</span>':'')+(q.hide?'<span class="muted" style="font-size:22px">'+q.p+'</span>':q.p)+sayBtn+'</div>';
  if(q.k==='choice'){const ops=shuf([q.ans].concat(q.opts));h+='<div class="opts">'+ops.map(o=>'<button class="opt" data-a="pick" data-v="'+esc(o)+'">'+esc(o)+'</button>').join('')+'</div>'}
  else{h+='<input class="typebox" id="tb" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="Respuesta"><div class="row" style="margin-top:12px"><button class="btn grow" id="ck" data-a="check">Comprobar</button>'+(q.h&&!SE.o.test?'<button class="btn sec" data-a="hint">💡</button>':'')+'<button class="btn sec" data-a="idk">No lo sé</button></div><div class="muted" id="hn" style="margin-top:8px"></div>'}
  A.innerHTML=h+'<div class="spacer"></div>';
  if(q.say)setTimeout(()=>say(q.say,q.rate),200);
  const tb=$('#tb');if(tb){tb.focus();tb.addEventListener('keydown',e=>{if(e.key==='Enter')ACT.check()})}}
function sheet(ok,q,note,given){const old=$('#sheet');if(old)old.remove();const d=document.createElement('div');d.id='sheet';d.className='sheet '+(SE.o.test?'good':(ok?'good':'bad'));
  let h;
  if(SE.o.test){h='<div class="in"><h3>Anotado</h3><button class="btn block" data-a="next" id="nx">Continúa</button></div>'}
  else{h='<div class="in"><h3>'+(ok?['¡Muy bien!','¡Perfecto!','¡Exacto!','¡Sí!'][rnd(4)]:'Casi…')+'</h3>';
    if(!ok)h+='<p>Respuesta correcta: <b>'+esc(q.ans)+'</b>'+(q.sayAns||q.k==='build'||q.k==='speak'?' '+spk(q.ans):'')+'</p>'+(given?'<small>Has escrito: '+esc(given)+'</small>':'');
    if(note)h+='<p>'+esc(note)+'</p>';
    if(q.e)h+='<p>'+esc(q.e)+'</p>';
    h+='<button class="btn block" data-a="next" id="nx">Continúa</button></div>'}
  d.innerHTML=h;document.body.appendChild(d);const nx=$('#nx');if(nx)nx.focus()}
function record(ok,q){SE.tot++;S.stat.tot++;
  if(q.key&&q.key.slice(0,2)==='p:')bump(q.key.slice(2),ok);
  if(q.blk!=null){const b=SE.blk[q.blk]||(SE.blk[q.blk]={ok:0,tot:0});b.tot++;if(ok)b.ok++}
  if(ok){SE.ok++;S.stat.ok++;SE.combo++;SE.max=Math.max(SE.max,SE.combo);const x=SE.o.per!=null?SE.o.per:10;SE.xp+=x+(SE.combo>=5?2:0);if(q.key&&S.weak[q.key])delete S.weak[q.key]}
  else{SE.combo=0;(SE.miss=SE.miss||[]);if(!SE.miss.some(m=>m.p===(q.p||q.es)&&m.a===q.ans))SE.miss.push({p:String(q.p||q.es||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim(),a:q.ans||'',e:q.e||''});
    if(q.key&&!SE.o.test)S.weak[q.key]=(S.weak[q.key]||0)+1;
    if(!SE.o.test&&!SE.o.noRetry&&!q._r&&SE.qs.length<40){SE.qs.push(Object.assign({},q,{_r:1}))}}
  save()}
function finishQ(ok,q,note,given){SE.locked=true;SE.lastOk=ok;record(ok,q);if(SE.o.onAnswer)SE.o.onAnswer(q,ok);sheet(ok,q,note,given)}
const ACT={};
ACT.say=(v,el)=>say(v,el&&el.dataset&&el.dataset.r?+el.dataset.r:undefined);ACT.slow=v=>say(v,.55);
ACT.pick=(v,el)=>{if(SE.locked)return;const q=SE.cur;const ok=v===q.ans;
  document.querySelectorAll('.opt').forEach(b=>{if(b.dataset.v===q.ans&&!SE.o.test)b.classList.add('good');else if(b===el&&!SE.o.test)b.classList.add('bad');if(SE.o.test&&b===el)b.classList.add('good')});
  if(!SE.o.test&&(q.sayAns||q.say))say(q.sayAns&&q.ans.length<80?q.ans:q.say||q.ans);
  finishQ(ok,q)};
ACT.check=()=>{if(SE.locked)return;const q=SE.cur;
  if(q.k==='build'){const w=SE.line.map(i=>(q.tok.concat(q.extra||[]))[i]);const ok=w.join(' ').toLowerCase()===q.ans.toLowerCase();
    $('#ln').classList.add(SE.o.test?'good':(ok?'good':'bad'));if(ok&&!SE.o.test)say(q.ans);finishQ(ok,q,'',w.join(' '));return}
  const tb=$('#tb');if(!tb)return;const val=tb.value;if(!val.trim()){tb.focus();return}
  const r=checkType(q,val);tb.classList.add(SE.o.test?'good':(r.ok?'good':'bad'));tb.disabled=true;if(r.ok&&q.sayAns&&!SE.o.test)say(q.ans);finishQ(r.ok,q,r.note,r.ok?'':val)};
ACT.idk=()=>{if(SE.locked)return;const tb=$('#tb');if(tb)tb.disabled=true;finishQ(false,SE.cur)};
function hintMask(a,full){return a.split(' ').map(w=>{const L=Array.from(w);if(L.length<=1)return w;const k=full?Math.max(1,Math.ceil(L.length/2)):1;return L.map((c,i)=>i<k||!/[A-Za-zÀ-ÿ0-9]/.test(c)?c:'_').join('')}).join(' ')}
ACT.hint=()=>{const q=SE.cur,a=String((q.alts&&q.alts[0])||q.ans||'');q.hl=Math.min((q.hl||0)+1,3);const L=q.hl;
  let t='💡 '+q.h;if(L>=2&&a)t+='<br>🔤 Empieza por «'+esc(a[0])+'» · '+a.replace(/[^A-Za-z]/g,'').length+' letras.';
  if(L>=3&&a)t+='<br>✏️ <b style="letter-spacing:2px">'+esc(hintMask(a,false))+'</b>';
  $('#hn').innerHTML=t+(L<3?'<br><small>Toca 💡 otra vez para ver más.</small>':'')};
ACT.wt=(v,el)=>{if(SE.locked)return;SE.line.push(+v);el.classList.add('gone');redrawLine()};
function redrawLine(){const q=SE.cur,all=q.tok.concat(q.extra||[]);$('#ln').innerHTML=SE.line.map((i,n)=>'<button class="wt" data-a="wl" data-v="'+n+'">'+esc(all[i])+'</button>').join('');$('#ck').disabled=!SE.line.length}
ACT.wl=(v)=>{if(SE.locked)return;const idx=SE.line.splice(+v,1)[0];const b=document.querySelector('#bk .wt[data-v="'+idx+'"]');if(b)b.classList.remove('gone');redrawLine()};
ACT.flip=()=>{const b=$('#bk');if(!b)return;b.hidden=false;$('#fbb').hidden=false;$('#fh').hidden=true};
ACT.fyes=()=>{const q=SE.cur;if(q.key&&q.key.slice(0,2)==='p:')bump(q.key.slice(2),true);SE.tot++;SE.ok++;if(q.key&&S.weak[q.key])delete S.weak[q.key];SE.xp+=SE.o.per!=null?SE.o.per:3;SE.i++;save();showQ()};
ACT.fno=()=>{const q=SE.cur;if(q.key&&q.key.slice(0,2)==='p:')bump(q.key.slice(2),false);SE.tot++;if(q.key)S.weak[q.key]=(S.weak[q.key]||0)+1;if(!q._r&&SE.qs.length<40)SE.qs.push(Object.assign({},q,{_r:1}));SE.i++;save();showQ()};
ACT.next=()=>{const s=$('#sheet');if(s)s.remove();
  if(SE.o.more&&SE.i+1>=SE.qs.length){const nq=SE.o.more(SE.cur,SE.lastOk,SE.tot);if(nq)SE.qs.push(nq)}
  SE.i++;showQ()};
ACT.quit=()=>{const s=$('#sheet');if(s)s.remove();leaveSession();showCur()};
function leaveSession(){document.body.classList.remove('in-session');try{speechSynthesis.cancel()}catch(e){}}
function endSession(){const o=SE.o;const acc=SE.tot?SE.ok/SE.tot:0;let bonus=0;
  if(!o.test&&acc>=.8)bonus=o.bonus!=null?o.bonus:15;
  addXP(SE.xp+bonus);
  const res={acc:acc,ok:SE.ok,tot:SE.tot,xp:SE.xp+bonus,blk:SE.blk,max:SE.max,miss:SE.miss||[]};
  if(o.onDone)o.onDone(res);
  leaveSession();
  if(o.custom){o.custom(res);return}
  const pct=Math.round(acc*100);
  const miss=(res.miss&&res.miss.length&&!o.test)?'<div class="card" style="text-align:left;margin-top:14px"><b>🔁 Repasa tus fallos</b><ul>'+res.miss.slice(0,8).map(m=>'<li>'+esc(m.p)+' → <b>'+esc(m.a)+'</b></li>').join('')+'</ul></div>':'';
  $('#app').innerHTML='<div class="card" style="text-align:center;margin-top:20px"><div class="big">'+(pct>=90?'🏆':pct>=70?'🎉':pct>=50?'👍':'💪')+'</div><h1>'+(o.title||'Sesión terminada')+'</h1><p style="font-size:22px">'+SE.ok+' / '+SE.tot+' · '+pct+' %</p><p class="muted">+'+(SE.xp+bonus)+' XP'+(bonus?' (incluye bonus)':'')+' · mejor racha ×'+SE.max+'</p>'+(res.html||'')+'</div>'+miss+(o.extra?o.extra(res):'')+'<button class="btn block" data-a="done">Continúa</button>'+(Object.keys(S.weak).length&&!o.test?'<button class="btn sec block" style="margin-top:10px" data-a="weak">Repasa las frases débiles ('+Object.keys(S.weak).length+')</button>':'')}
