/* ===== NIVEL ACTUAL, REPETICIÓN ESPACIADA Y GENERADORES DE PREGUNTAS ===== */
const LVN=['','A1','A2','B1','B2'];
const LV=()=>S.test&&S.test.lv?S.test.lv:(S.prof&&S.prof.lv0?S.prof.lv0:1);
const modPh=(m,lv)=>m.ph.filter(p=>p.lv<=(lv||LV()));
const allPh=lv=>MODS.reduce((a,m)=>a.concat(modPh(m,lv)),[]);
function srsMark(k,ok){if(!k||!PH[k])return;const T=dnum();const r=S.srs[k];
  if(ok){if(r&&r.d>T)return;const i=(r?r.i:0)+1;S.srs[k]={i:i,d:T+INTV[Math.min(i-1,INTV.length-1)]}}
  else S.srs[k]={i:0,d:T+1}}
function srsDue(){const T=dnum();return Object.keys(S.srs).filter(k=>S.srs[k].d<=T&&PH[k]).sort((a,b)=>S.srs[a].d-S.srs[b].d).map(k=>PH[k])}
function dist(p,field,n){const seen={};seen[nfc(p[field])]=1;
  const same=MOD[p.mod].ph.filter(x=>x.id!==p.id&&x.lv<=Math.max(p.lv,LV()));
  const rest=allPh(Math.max(p.lv,LV())).filter(x=>x.id!==p.id&&x.mod!==p.mod);const out=[];
  const cand=shuf(same).concat(shuf(rest));
  for(const x of cand){const k=nfc(x[field]);if(seen[k])continue;seen[k]=1;out.push(x[field]);if(out.length>=n)break}
  return out}
const trQ=p=>({k:'choice',kind:'Traduce',blk:'vocab',key:'p:'+p.id,p:'¿Qué significa? <b>'+esc(p.en)+'</b>',say:p.en,ans:p.es,opts:dist(p,'es',3),e:p.en+' = '+p.es});
const revQ=p=>({k:'choice',kind:'¿Cómo se dice?',blk:'vocab',key:'p:'+p.id,p:esc(p.es),ans:p.en,opts:dist(p,'en',3),sayAns:1,e:p.en});
const listenQ=p=>({k:'choice',kind:'Escucha (acento americano)',blk:'oral',key:'p:'+p.id,p:'🎧 ¿Qué significa lo que oyes?',hide:true,say:p.en,rate:fastRate(),ans:p.es,opts:dist(p,'es',3),e:p.en+' = '+p.es});
function clozeQ(p){const w=p.en.split(' ');
  const idx=w.map((x,i)=>({x:x,i:i})).filter(o=>o.i>0&&/^[A-Za-z']{4,}[.,?!]*$/.test(o.x));
  if(w.length<3||!idx.length)return revQ(p);
  const t=one(idx);const word=t.x.replace(/[.,?!]+$/,'');const w2=w.slice();w2[t.i]=w2[t.i].replace(word,'_____');
  return{k:'type',kind:'Completa la frase',blk:'struct',key:'p:'+p.id,p:esc(w2.join(' '))+'<br><small class="muted">'+esc(p.es)+'</small>',h:'Significa: '+p.es,ans:word,alts:[word],sayAns:1,e:p.en+' · '+p.es}}
function buildQ(p){const tok=p.en.split(' ');if(tok.length<3||tok.length>9)return revQ(p);
  const low=tok.map(t=>t.toLowerCase()),pool=[];
  allPh(Math.max(p.lv,LV())).forEach(x=>x.en.split(' ').forEach(w=>{if(/^[a-z]{3,7}$/.test(w)&&low.indexOf(w)<0&&pool.indexOf(w)<0)pool.push(w)}));
  return{k:'build',kind:'Ordena la frase',blk:'struct',key:'p:'+p.id,es:p.es,tok:tok,extra:pick(pool,1),ans:p.en,e:p.en}}
const KINDS={tr:trQ,rev:revQ,listen:listenQ,cloze:clozeQ,build:buildQ};
function weakFlags(){const c=(S.test&&S.test.cat)||{};const w={};const lo=k=>c[k]&&c[k].tot>=3&&c[k].ok/c[k].tot<.6;
  w.vocab=lo('v');w.gram=lo('g');w.read=lo('r');w.oral=lo('l');return w}
function kindList(){const w=weakFlags();let a=['tr','rev','listen','build','cloze'];
  if(w.oral)a=a.concat(['listen','listen']);if(w.gram)a=a.concat(['cloze','build']);if(w.vocab)a=a.concat(['tr','rev']);
  if(LV()>=3)a=a.concat(['listen','cloze','build']);if(!S.set.voice)a=a.filter(x=>x!=='listen');return a}
function mixQs(ps,n,kinds){const ks=kinds||kindList();const out=[];const list=shuf(ps);
  for(let i=0;i<n&&list.length;i++){const p=list[i%list.length];const kd=KINDS[ks[rnd(ks.length)]];const q=kd(p);if(q.opts&&q.opts.length<2)continue;out.push(q)}
  return out}
function keyToQ(k){const p=PH[k.slice(2)];if(!p)return null;return one([trQ,revQ,listenQ])(p)}
function cultQs(n){return pick(CULT,n).map(c=>({k:'choice',kind:'Cultura práctica',blk:'cult',p:esc(c[0]),ans:c[1],opts:c[2],e:c[3]}))}
function lessonQs(l){return l.q.map(x=>{
  if(x[0]==='c')return{k:'choice',kind:'Gramática',blk:'lesson',p:esc(x[1]),ans:x[2],opts:x[3],e:x[4]};
  if(x[0]==='t')return{k:'type',kind:'Escribe',blk:'lesson',p:esc(x[1]),h:'Repasa la teoría de la lección.',ans:x[2].split('|')[0],alts:x[2].split('|'),e:x[3]};
  const tok=x[2].split(' ');return{k:'build',kind:'Ordena la frase',blk:'lesson',es:x[1],tok:tok,extra:[],ans:x[2],e:x[2]}})}
