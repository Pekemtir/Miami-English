/* ===== TEST DE NIVEL ADAPTATIVO Y TEST FINAL ===== */
let TS=null;
const TKIND={v:'Vocabulario',g:'Gramática',r:'Lectura',l:'Escucha (acento americano)'};
const TCYCLE=['v','g','l','v','g','r','l','v','g','l','r','g'];
function tbQ(it,idx){const base={k:'choice',kind:TKIND[it.k],blk:it.k,_tb:idx,ans:it.a,opts:it.w};
  if(it.k==='l')return Object.assign(base,{p:esc(it.p),hide:true,say:it.say,rate:fastRate()});
  return Object.assign(base,{p:esc(it.p)})}
function pickTB(k,lv){const free=i=>!TS.used.has(i)&&TB[i].k===k;let c=[];
  [lv,lv-1,lv+1,lv-2,lv+2].forEach(L=>{if(!c.length&&L>=1&&L<=4)c=TB.map((x,i)=>i).filter(i=>free(i)&&TB[i].lv===L)});
  if(!c.length)c=TB.map((x,i)=>i).filter(free);
  if(!c.length)return -1;return one(c)}
const tk=n=>{const k=TCYCLE[n%TCYCLE.length];return(!S.set.voice&&k==='l')?['v','g','r'][n%3]:k};
function startLevelTest(){TS={cur:2,used:new Set(),res:[],streak:0,n:0,mode:'level'};if(!S.set.voice)toast('🔇 Sin sonido: se omiten las preguntas de escucha');
  const i=pickTB(tk(0),TS.cur);TS.used.add(i);
  startSession([tbQ(TB[i],i)],{test:true,total:30,per:0,title:'Test de nivel',more:testNext,custom:testResult,onAnswer:tsRec})}
function tsRec(q,ok){const it=TB[q._tb];TS.res.push({k:it.k,lv:it.lv,ok:ok})}
function testNext(q,ok){TS.n++;
  if(ok){TS.streak++;if(TS.streak>=2){TS.cur=Math.min(4,TS.cur+1);TS.streak=0}}else{TS.cur=Math.max(1,TS.cur-1);TS.streak=0}
  if(TS.n>=30)return null;
  const i=pickTB(tk(TS.n),TS.cur);if(i<0)return null;TS.used.add(i);return tbQ(TB[i],i)}
function estimate(res){const by={1:{ok:0,tot:0},2:{ok:0,tot:0},3:{ok:0,tot:0},4:{ok:0,tot:0}};res.forEach(r=>{by[r.lv].tot++;if(r.ok)by[r.lv].ok++});
  const a=L=>by[L].tot?by[L].ok/by[L].tot:0;let lv=1;
  if(by[2].tot>=2&&a(2)>=.6)lv=2;
  if(by[3].tot>=3&&a(3)>=.6&&(by[2].tot<2||a(2)>=.5))lv=3;
  if(lv===3&&by[4].tot>=3&&a(4)>=.6&&a(3)>=.6)lv=4;
  const cat={v:{ok:0,tot:0},g:{ok:0,tot:0},r:{ok:0,tot:0},l:{ok:0,tot:0}};res.forEach(r=>{cat[r.k].tot++;if(r.ok)cat[r.k].ok++});
  const tot=res.length,ok=res.filter(r=>r.ok).length;return{lv:lv,cat:cat,score:tot?Math.round(ok/tot*100):0,n:tot}}
const CATN={v:'Vocabulario',g:'Gramática',r:'Lectura',l:'Comprensión oral'};
function catBars(cat){return Object.keys(CATN).map(k=>{const c=cat[k]||{ok:0,tot:0};const p=c.tot?Math.round(c.ok/c.tot*100):0;return'<div style="margin:8px 0"><div class="res"><span>'+CATN[k]+'</span><b>'+(c.tot?p+' %':'—')+'</b></div><div class="bar"><i style="width:'+p+'%"></i></div></div>'}).join('')}
function testResult(res){
  const last=TS.res.slice();const e=estimate(last);
  if(TS.mode==='level'){S.test={lv:e.lv,cat:e.cat,score:e.score,date:today(),used:Array.from(TS.used),n:e.n};S.plan=null;save();
    const w=weakFlags();const wk=[];if(w.oral)wk.push('comprensión oral');if(w.gram)wk.push('gramática');if(w.vocab)wk.push('vocabulario');if(w.read)wk.push('lectura');
    $('#app').innerHTML='<div class="card" style="text-align:center;margin-top:16px"><div class="big">🌴</div><h1>Tu nivel: '+LVN[e.lv]+'</h1><p class="muted">'+e.n+' preguntas · '+e.score+' % de acierto</p></div><div class="card"><h3>Tus habilidades</h3>'+catBars(e.cat)+'<p class="muted">'+(wk.length?'Puntos a reforzar: <b>'+wk.join(', ')+'</b>. El plan les dará más peso.':'No hay ningún punto claramente flojo. ¡Buen punto de partida!')+'</p></div><button class="btn block" data-a="mkplan">Generar mi plan</button><button class="btn sec block" style="margin-top:10px" data-a="rtest">Repetir el test</button>';
    window.scrollTo(0,0);checkBadges();return}
  const prev=S.test||{lv:1,cat:{},score:0};S.fin={lv:e.lv,cat:e.cat,score:e.score,date:today()};save();checkBadges();
  const diff=e.score-prev.score;
  $('#app').innerHTML='<div class="card" style="text-align:center;margin-top:16px"><div class="big">🏁</div><h1>Test final</h1><p>Nivel inicial <b>'+LVN[prev.lv]+'</b> → ahora <b>'+LVN[e.lv]+'</b></p><p class="muted">Aciertos: '+prev.score+' % → '+e.score+' % ('+(diff>=0?'+':'')+diff+' puntos)</p></div><div class="card"><h3>Habilidades ahora</h3>'+catBars(e.cat)+'</div><button class="btn block" data-a="done">Continúa</button>'}
function startFinalTest(){const used=new Set((S.test&&S.test.used)||[]);
  const want=[[1,4],[2,5],[3,6],[4,5]];const picks=[];
  want.forEach(w=>{const okk=i=>S.set.voice||TB[i].k!=='l';const pool=TB.map((x,i)=>i).filter(i=>TB[i].lv===w[0]&&okk(i)&&!used.has(i));const pool2=TB.map((x,i)=>i).filter(i=>TB[i].lv===w[0]&&okk(i)&&used.has(i));
    shuf(pool).concat(shuf(pool2)).slice(0,w[1]).forEach(i=>picks.push(i))});
  TS={cur:2,used:new Set(picks),res:[],streak:0,n:0,mode:'final'};
  const qs=shuf(picks).map(i=>tbQ(TB[i],i));
  startSession(qs,{test:true,per:0,title:'Test final',custom:r=>{testResult(r)},onAnswer:tsRec})}
