/* ===== SIMULACIONES DE CONVERSACIÓN (diálogos ramificados preescritos, voz del navegador) ===== */
let SM=null;
const pname=()=>(S.prof&&S.prof.name)||'Ana';
const sub=t=>String(t==null?'':t).replace(/\{NAME\}/g,pname());
const starsTxt=n=>'★'.repeat(n)+'☆'.repeat(3-n);
const npcRate=()=>LV()>=3?fastRate():(LV()===2?.95:.85);
function simBest(id){let b=0;MODS.forEach(m=>{const v=prog(m.id).sims[id];if(v&&v>b)b=v});return b}
function simIntro(id){const s=SIMS.find(x=>x.id===id);if(!s)return'<p>No encuentro la simulación.</p>';const m=MOD[s.mod];
  return'<h1>'+m.ic+' '+esc(s.t)+'</h1><div class="card"><p>'+esc(s.sc)+'</p><p class="muted">Hablas con: <b>'+esc(s.who)+'</b> · '+s.nd.length+' turnos · nivel de ayuda: '+LVN[LV()]+'</p><p class="muted">'+(LV()===1?'Verás la traducción de cada frase.':'La traducción está oculta: tócala si la necesitas.')+' Si eliges una respuesta que no sirve, el otro responde «Sorry?» y puedes intentarlo de nuevo.</p><p>Mejor resultado: <span class="stars">'+starsTxt(simBest(id))+'</span></p></div><button class="btn block" data-a="simgo" data-v="'+id+'">🎬 Empezar la escena</button>'}
function startSim(id){const s=SIMS.find(x=>x.id===id);if(!s)return;
  const nodes={};s.nd.forEach((n,i)=>nodes[n[0]]={id:n[0],n:sub(n[1]),e:n[2],o:n[3],i:i});
  SM={s:s,nodes:nodes,cur:s.nd[0][0],hist:[],pts:0,max:0,slips:0,turns:[],done:0,tr:LV()===1,used:{},lock:false,react:''};
  document.body.classList.add('in-session');window.scrollTo(0,0);simRender(true)}
function bub(b,showEs){return'<div class="bub '+(b.w==='npc'?'npc':'me')+'">'+esc(b.t)+(showEs&&b.e?'<small>'+esc(sub(b.e))+'</small>':'')+(b.w==='npc'?' '+spk(b.t):'')+'</div>'}
function simRender(speak){const s=SM.s,nd=SM.nodes[SM.cur];const A=$('#app');
  let h='<div class="qtop"><button class="x" data-a="simquit" aria-label="Salir">✕</button><div class="prog"><i style="width:'+Math.round(SM.done/s.nd.length*100)+'%"></i></div></div><div class="qkind">🎬 '+esc(s.t)+' · '+esc(s.who)+'</div>';
  h+=SM.hist.map(b=>bub(b,LV()<=2&&b.e)).join('');
  h+='<div class="bub npc">'+esc(nd.n)+(SM.tr?'<small>'+esc(sub(nd.e))+'</small>':'')+' '+spk(nd.n)+'<button class="spk" data-a="slow" data-v="'+esc(nd.n)+'" aria-label="Despacio">🐢</button></div>';
  if(!SM.ord||SM.ordFor!==SM.cur){SM.ord=shuf(nd.o.map((x,i)=>i));SM.ordFor=SM.cur}
  h+='<div class="opts">'+SM.ord.map(i=>{const o=nd.o[i];const dis=SM.used[SM.cur+':'+i];return'<button class="opt'+(dis?' bad':'')+'" '+(dis?'disabled ':'')+'data-a="simpick" data-v="'+i+'">'+esc(sub(o[0]))+(SM.tr?'<small class="muted" style="display:block;font-weight:600">'+esc(sub(o[1]))+'</small>':'')+'</button>'}).join('')+'</div>';
  h+='<div class="row" style="margin-top:12px"><button class="btn sec sm" data-a="simtr">'+(SM.tr?'🙈 Ocultar traducción':'👁 Ver traducción')+'</button></div><div class="spacer"></div>';
  A.innerHTML=h;SM.lock=false;
  if(speak){const t=(SM.react?SM.react+' ':'')+nd.n;SM.react='';say(t,npcRate())}
  window.scrollTo(0,document.body.scrollHeight)}
ACT.sim=id=>go('sim',id,true);
ACT.simgo=id=>startSim(id);
ACT.simtr=()=>{if(!SM)return;SM.tr=!SM.tr;simRender(false)};
ACT.simquit=()=>{const e=$('#sheet');if(e)e.remove();SM=null;leaveSession();showCur()};
ACT.simpick=v=>{if(!SM||SM.lock)return;const nd=SM.nodes[SM.cur];const o=nd.o[+v];SM.lock=true;SM.pick={i:+v,o:o,nd:nd};
  const sc=o[2];const best=nd.o.filter(x=>x[2]===2)[0];
  const d=document.createElement('div');d.id='sheet';d.className='sheet '+(sc===0?'bad':'good');
  let h='<div class="in"><h3>'+(sc===2?['¡Perfecto!','¡Muy natural!','¡Eso es!'][rnd(3)]:sc===1?'Vale, se entiende':'Mmm, eso no encaja')+'</h3><p>'+esc(sub(o[3]))+'</p>';
  if(sc===1&&best)h+='<p>Más natural: <b>'+esc(sub(best[0]))+'</b> '+spk(sub(best[0]))+'</p>';
  h+='<button class="btn block" data-a="simnext" id="nx">'+(sc===0?'Otra vez':'Continúa')+'</button></div>';
  d.innerHTML=h;document.body.appendChild(d);const nx=$('#nx');if(nx)nx.focus();
  if(sc===0){SM.slips++;SM.used[SM.cur+':'+v]=1;say('Sorry? I didn\'t catch that.',npcRate())}};
ACT.simnext=()=>{const e=$('#sheet');if(e)e.remove();if(!SM||!SM.pick)return;const p=SM.pick,sc=p.o[2];
  if(sc===0){SM.pick=null;simRender(false);return}
  const pts=Math.max(0,sc-(SM.slips?1:0));SM.pts+=pts;SM.max+=2;SM.turns.push({n:p.nd.id,sc:sc,slips:SM.slips,said:sub(p.o[0]),best:sub((p.nd.o.filter(x=>x[2]===2)[0]||p.o)[0])});SM.slips=0;SM.done++;
  SM.hist.push({w:'npc',t:p.nd.n,e:p.nd.e});SM.hist.push({w:'me',t:sub(p.o[0]),e:p.o[1]});
  if(p.o[4])SM.hist.push({w:'npc',t:sub(p.o[4])});
  const to=p.o[5]||(SM.s.nd[p.nd.i+1]?SM.s.nd[p.nd.i+1][0]:'end');SM.pick=null;
  if(to==='end'||!SM.nodes[to]){simFinish();return}
  SM.cur=to;SM.tr=LV()===1;SM.react=p.o[4]?sub(p.o[4]):'';simRender(true)};
function simFinish(){const s=SM.s,pct=SM.max?SM.pts/SM.max:0;const st=pct>=.85?3:pct>=.65?2:1;
  const pr=prog(s.mod);const before=pr.sims[s.id]||0;pr.sims[s.id]=Math.max(before,st);S.stat.sims++;
  addXP(10*st+5);const wasDone=pr.done;if(modDone(s.mod)){pr.done=true}save();checkBadges();
  leaveSession();
  const imp=SM.turns.filter(t=>t.sc<2||t.slips);
  const more=simsOf(s.mod).filter(x=>x.id!==s.id);
  $('#app').innerHTML='<div class="card" style="text-align:center;margin-top:16px"><div class="big">🎬</div><h1>Escena completada</h1><p class="stars" style="font-size:34px">'+starsTxt(st)+'</p><p>'+SM.pts+' / '+SM.max+' puntos · +'+(10*st+5)+' XP</p></div>'+
   (imp.length?'<div class="card"><b>Para mejorar</b><ul>'+imp.map(t=>'<li>Dijiste: «'+esc(t.said)+'» · mejor: <b>'+esc(t.best)+'</b> '+spk(t.best)+'</li>').join('')+'</ul></div>':'<div class="card"><p>Sin fallos: ¡suena como un/a local!</p></div>')+
   (!wasDone&&pr.done?'<div class="card ch"><b>🎉 Módulo completado: '+esc(MOD[s.mod].n)+'</b></div>':'')+
   '<button class="btn block" data-a="simgo" data-v="'+s.id+'">🔁 Repetir la escena</button>'+
   (more.length?'<button class="btn sec block" style="margin-top:10px" data-a="sim" data-v="'+more[0].id+'">▶ Siguiente escena: '+esc(more[0].t)+'</button>':'')+
   '<button class="btn sec block" style="margin-top:10px" data-a="mod" data-v="'+s.mod+'">Volver a '+esc(MOD[s.mod].n)+'</button>';
  window.scrollTo(0,0);SM=null}
