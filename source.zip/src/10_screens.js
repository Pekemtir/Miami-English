/* ===== NAVEGACIÓN Y PANTALLAS (1/2) ===== */
let CUR={v:'home',a:null},NAV=[],TIMERS=[];
const TABS=['home','plan','practice','phrases','me'];
function clearTimers(){TIMERS.forEach(t=>{clearInterval(t);clearTimeout(t)});TIMERS=[]}
function go(v,a,sub){clearTimers();if(SE)SE=null;SM=null;leaveSession();
  if(sub){NAV.push(CUR)}else if(TABS.indexOf(v)>=0){NAV=[]}
  CUR={v:v,a:a};show()}
function showCur(){clearTimers();SE=null;show()}
function up(){clearTimers();SE=null;SM=null;leaveSession();CUR=NAV.pop()||{v:'home'};show()}
function show(){const A=$('#app');const f=V[CUR.v]||V.home;const sub=TABS.indexOf(CUR.v)<0;
  document.body.classList.toggle('sub',sub);
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.v===(TABS.indexOf(CUR.v)>=0?CUR.v:(CUR.tab||''))));
  $('#chips').innerHTML='<span class="chip" title="Racha">🔥 '+streakNow()+'</span><span class="chip" title="XP">⭐ '+S.xp+'</span>';
  A.innerHTML=f(CUR.a);window.scrollTo(0,0);if(f.post)f.post(CUR.a)}
const V={};
const pct=(a,b)=>b?Math.round(a/b*100):0;
const row=(ic,t,s,act,v,st,extra)=>'<button class="lrow'+(st==='done'?' done':'')+'" data-a="'+act+'"'+(v!=null?' data-v="'+esc(v)+'"':'')+'><span class="ic">'+ic+'</span><span class="grow"><b>'+t+'</b><small>'+s+'</small></span>'+(st==='done'?'<span class="ck">✓</span>':(extra||'<span>▶</span>'))+'</button>';
function ring(p){const r=34,c=2*Math.PI*r;return'<svg class="ring" viewBox="0 0 80 80" role="img" aria-label="Progreso"><circle class="bg" cx="40" cy="40" r="'+r+'"/><circle class="fg" cx="40" cy="40" r="'+r+'" stroke-dasharray="'+c+'" stroke-dashoffset="'+(c*(1-Math.min(1,p/100)))+'" transform="rotate(-90 40 40)"/><text x="40" y="48" text-anchor="middle">'+p+'%</text></svg>'}
function daysToTrip(){const d=S.prof&&S.prof.date;if(!d)return null;const n=Math.ceil((new Date(d+'T00:00:00')-new Date(today()+'T00:00:00'))/864e5);return n}
/* ----- INICIO ----- */
V.home=()=>{
  if(!S.prof)return'<div class="hero" style="margin-top:14px"><div class="sun"></div><div><h1>Miami English</h1><p class="muted" style="margin:0">Inglés a medida para tu viaje a Miami</p></div></div><div class="card"><p>Responde unas preguntas, haz un test de nivel y la app te monta un <b>plan personalizado</b> con simulaciones de conversaciones reales: aeropuerto, restaurante, taxi, urgencias…</p><p class="muted">Gratis, sin cuentas. Todo se guarda solo en tu dispositivo.</p></div><button class="btn block" data-a="onb">🌴 Empezar</button><p class="muted" style="text-align:center;margin-top:18px">Proyecto independiente, sin afiliación con ninguna entidad oficial.</p>';
  let h='<h1>¡Hola, '+esc(S.prof.name)+'!</h1>';
  const dt=daysToTrip();if(dt!=null&&dt>=0)h+='<p class="muted">Faltan <b>'+dt+'</b> días para tu viaje · Nivel '+LVN[LV()]+'</p>';else h+='<p class="muted">Nivel '+LVN[LV()]+'</p>';
  if(!S.test)h+='<div class="card ch"><b>Falta tu test de nivel</b><p class="muted">Dura unos 12 minutos y decide el plan.</p><button class="btn block" data-a="tintro">Hacer el test</button></div>';
  else if(!S.plan)h+='<div class="card ch"><b>Tu plan aún no está generado</b><button class="btn block" data-a="mkplan">Generar mi plan</button></div>';
  else{const it=nextItem();const p=planPct();
    h+='<div class="card goal">'+ring(p)+'<div class="grow"><b>Tu plan</b><div class="muted">'+S.plan.items.filter(itemDone).length+' de '+S.plan.items.length+' pasos</div></div></div>';
    if(it){const L=itemLabel(it);h+='<h2>Hoy toca</h2>'+row(L.ic,esc(L.t),esc(L.s)+' · '+it.min+' min','stepgo',S.plan.items.indexOf(it),'',' <span>▶</span>')}
    else h+='<div class="card"><p>🎉 ¡Has completado todo el plan!</p></div>'}
  if(S.sug&&MOD[S.sug.mod])h+=sugCard(S.sug.mod,S.sug.skill);
  const br=bonusRec();if(br)h+='<div class="card ch"><b>🚀 Vas sobrada</b><p class="muted">Media del '+avgPrac()+' %. Siguiente reto opcional:</p>'+br.slice(0,2).map(m=>row(m.ic,esc(m.n),'Módulo extra','mod',m.id)).join('')+'</div>';
  h+=srsCard();
  h+='<h2>Atajos</h2><div class="tiles"><button class="tile" data-a="fastl"><span class="ic">🎧</span><span class="t">Escucha rápida</span><span class="s">Acento americano</span></button><button class="tile" data-a="daily"><span class="ic">⚡</span><span class="t">Mix del día</span><span class="s">10 preguntas</span></button><button class="tile" data-a="tab" data-v="phrases"><span class="ic">💬</span><span class="t">Frases clave</span><span class="s">Sin conexión</span></button><button class="tile" data-a="go" data-v="sims"><span class="ic">🎬</span><span class="t">Simulaciones</span><span class="s">Conversaciones</span></button></div>';
  h+='<div class="card" style="margin-top:14px"><div class="res"><span>Objetivo diario</span><b>'+dayXP()+' / '+S.goal+' XP</b></div><div class="bar"><i style="width:'+Math.min(100,pct(dayXP(),S.goal))+'%"></i></div></div>';
  return h};
ACT.tab=v=>go(v);ACT.go=v=>go(v,null,true);
ACT.done=()=>showCur();ACT.up=()=>up();
function sugCard(mod,skill){const m=MOD[mod];return'<div class="card ch"><b>💪 Punto débil en '+esc(m.n)+'</b><p class="muted">Tu '+SKN[skill]+' ha quedado por debajo del 75 %. Te sugiero reforzarlo (tú decides).</p><div class="row"><button class="btn sm" data-a="reinf" data-v="'+mod+':'+skill+'">Reforzar ahora</button><button class="btn sec sm" data-a="sugx">Seguir con el plan</button></div></div>'}
ACT.sugx=()=>{S.sug=null;save();showCur()};
ACT.reinf=v=>{const a=v.split(':');const mod=a[0],sk=a[1];S.sug=null;save();
  if(sk==='oral')return startDrill(mod);
  if(sk==='vocab'){const ps=modPh(MOD[mod]);return startSession(mixQs(ps,10,['tr','rev','tr','rev','listen']),{per:8,title:'Refuerzo: vocabulario'})}
  const g=GRM[MOD_GR[mod]];if(g&&!(S.les[g.id]&&S.les[g.id].best>=70))return go('lesson',g.id,true);
  startSession(mixQs(modPh(MOD[mod]),10,['cloze','build','cloze','build']),{per:8,title:'Refuerzo: estructura'})};
/* ----- ONBOARDING ----- */
let ONB=null;
function onbInit(){const P=S.prof||{};ONB={name:P.name||'',goal:P.goal||'tour',fears:(P.fears||[]).slice(),weeks:P.weeks||6,date:P.date||'',mins:P.mins||15,days:P.days||5,self:Object.assign({speak:2,listen:2,read:3},P.self||{}),lv0:P.lv0||0}}
ACT.onb=()=>{onbInit();go('onb',null,true)};
V.onb=()=>{if(!ONB)onbInit();const O=ONB;
  const pills=(arr,key,cur)=>'<div class="pills">'+arr.map(x=>'<button class="pill'+(String(cur)===String(x[0])?' on':'')+'" data-a="onset" data-v="'+key+':'+x[0]+'">'+(x[1]||'')+' '+x[2]+'</button>').join('')+'</div>';
  const sc=(k)=>'<div class="pills">'+[1,2,3,4,5].map(n=>'<button class="pill'+(O.self[k]===n?' on':'')+'" data-a="onself" data-v="'+k+':'+n+'">'+n+'</button>').join('')+'</div>';
  return'<h1>Cuéntame sobre ti</h1><p class="muted">Paso 1 de 3 · 2 minutos</p>'+
  '<div class="card"><label for="onn"><b>¿Cómo te llamas?</b></label><input id="onn" class="fld" type="text" maxlength="30" autocomplete="given-name" value="'+esc(O.name)+'" placeholder="Tu nombre"></div>'+
  '<div class="card"><b>¿Para qué quieres inglés?</b>'+pills(GOALS,'goal',O.goal)+'</div>'+
  '<div class="card"><b>¿Qué te preocupa más? (elige las que quieras)</b><div class="pills">'+FEARS.map(f=>'<button class="pill'+(O.fears.indexOf(f[0])>=0?' on':'')+'" data-a="onfear" data-v="'+f[0]+'">'+f[1]+' '+f[2]+'</button>').join('')+'</div></div>'+
  '<div class="card"><b>¿Cuánto falta para el viaje?</b><div class="pills">'+[2,3,4,6,8,12].map(w=>'<button class="pill'+(!O.date&&O.weeks===w?' on':'')+'" data-a="onset" data-v="weeks:'+w+'">'+w+' semanas</button>').join('')+'</div><label for="ond" class="muted">…o pon la fecha del viaje (opcional):</label><input id="ond" class="fld" type="date" min="'+today()+'" value="'+esc(O.date)+'"></div>'+
  '<div class="card"><b>Minutos al día</b><div class="pills">'+[10,15,20,30,45].map(m=>'<button class="pill'+(O.mins===m?' on':'')+'" data-a="onset" data-v="mins:'+m+'">'+m+' min</button>').join('')+'</div><b>Días por semana</b><div class="pills">'+[3,5,7].map(d=>'<button class="pill'+(O.days===d?' on':'')+'" data-a="onset" data-v="days:'+d+'">'+d+' días</button>').join('')+'</div></div>'+
  '<div class="card"><b>Autoevaluación (1 = nada, 5 = muy bien)</b><p class="muted" style="margin:4px 0">Hablar</p>'+sc('speak')+'<p class="muted" style="margin:4px 0">Entender cuando me hablan</p>'+sc('listen')+'<p class="muted" style="margin:4px 0">Leer</p>'+sc('read')+'<b>Nivel que crees tener</b><div class="pills">'+[[0,'','No lo sé'],[1,'','A1 · muy básico'],[2,'','A2 · me defiendo'],[3,'','B1 · intermedio'],[4,'','B2 · avanzado']].map(x=>'<button class="pill'+(O.lv0===x[0]?' on':'')+'" data-a="onset" data-v="lv0:'+x[0]+'">'+x[2]+'</button>').join('')+'</div><p class="muted">El test de nivel lo confirmará.</p></div>'+
  '<button class="btn block" data-a="onbsave">Continuar al test de nivel</button><p class="muted" style="text-align:center">Tus datos no salen de este dispositivo.</p>'};
ACT.onset=v=>{const i=v.indexOf(':');const k=v.slice(0,i),x=v.slice(i+1);ONB[k]=(k==='goal')?x:+x;if(k==='weeks')ONB.date='';showCur()};
ACT.onself=v=>{const a=v.split(':');ONB.self[a[0]]=+a[1];showCur()};
ACT.onfear=v=>{const i=ONB.fears.indexOf(v);if(i>=0)ONB.fears.splice(i,1);else ONB.fears.push(v);showCur()};
ACT.onbsave=()=>{const O=ONB;O.name=(O.name||'').trim();if(!O.name){toast('Escribe tu nombre');const e=$('#onn');if(e)e.focus();return}
  let weeks=O.weeks;if(O.date){const n=Math.ceil((new Date(O.date+'T00:00:00')-new Date(today()+'T00:00:00'))/(7*864e5));weeks=Math.max(1,Math.min(16,n))}
  const lv0=O.lv0||(O.self.speak+O.self.listen+O.self.read>=11?2:1);
  S.prof={name:O.name,goal:O.goal,fears:O.fears.slice(),weeks:weeks,date:O.date,mins:O.mins,days:O.days,self:O.self,lv0:lv0};S.plan=null;save();
  go('tintro',null,false)};
/* ----- TEST: intro ----- */
V.tintro=()=>'<h1>Test de nivel</h1><p class="muted">Paso 2 de 3</p><div class="card"><p>Son hasta <b>30 preguntas</b> (≈ 12 min) de vocabulario, gramática, lectura y comprensión oral. Se adapta a ti: si aciertas suben de dificultad y si fallas bajan.</p><p>Al final verás tu nivel (A1, A2, B1 o B2) y tus puntos débiles. <b>No te enseña las respuestas</b> durante el test.</p><p class="muted">Necesitas sonido para las preguntas de escucha.</p></div><button class="btn block" data-a="stest">🧪 Empezar el test</button><button class="btn sec block" style="margin-top:10px" data-a="skiptest">Saltar y usar mi nivel estimado ('+LVN[(S.prof&&S.prof.lv0)||1]+')</button>';
ACT.tintro=()=>go('tintro',null,true);
ACT.stest=()=>startLevelTest();ACT.rtest=()=>startLevelTest();
ACT.skiptest=()=>{S.test={lv:(S.prof&&S.prof.lv0)||1,cat:{},score:0,date:today(),used:[],n:0,skipped:true};S.plan=null;save();ACT.mkplan()};
ACT.mkplan=()=>{buildPlan();go('plan',null,false);toast('✅ Plan generado')};
