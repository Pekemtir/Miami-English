/* ===== SIMULACIONES: cada turno = [id, línea del otro, traducción, opciones]
   opción = [inglés, castellano, puntos(2 mejor,1 aceptable,0 no vale), explicación, reacción opcional, saltar a (opcional)] ===== */
const SIMS=[
{id:'surv1',mod:'surv',t:'Un café rápido',sc:'Pides un café y el barista habla muy rápido. Practica pedir que repita.',who:'Barista',lv:1,nd:[
['a',"Hi there! What can I get started for you today?","¡Hola! ¿Qué te pongo hoy?",[
 ["Hi! Could I have a coffee, please?","¡Hola! ¿Me pone un café, por favor?",2,"Natural y educado."],
 ["Coffee.","Café.",1,"Se entiende, pero suena seco. Añade «please»."],
 ["I am wanting one coffee yes.","Estoy queriendo un café sí.",0,"Suena forzado. Di «I'd like a coffee, please»."]]],
['b',"Sure! Hot or iced, and what size? Small, medium, or large?","¿Caliente o con hielo, y de qué tamaño? (dicho muy rápido)",[
 ["Sorry, could you repeat that, please?","Perdón, ¿podría repetirlo, por favor?",2,"Justo lo que hay que hacer cuando no entiendes."],
 ["I don't understand.","No entiendo.",1,"Vale, pero ayuda más pedir algo concreto: repetir o hablar más despacio."],
 ["Yes, yes.","Sí, sí.",0,"No has contestado a la pregunta. Si no entiendes, pídelo."]],"Of course!"],
['c',"Hot or iced? And small, medium, or large?","¿Caliente o con hielo? ¿Y pequeño, mediano o grande? (despacio)",[
 ["Hot, and medium, please.","Caliente y mediano, por favor.",2,"Perfecto."],
 ["Hot medium.","Caliente, mediano.",1,"Funciona, pero añade «please»."],
 ["Yes, please.","Sí, por favor.",0,"No es una respuesta a «hot or iced»."]]],
['d',"That's four fifty. Cash or card?","Son 4,50. ¿Efectivo o tarjeta?",[
 ["Card, please.","Con tarjeta, por favor.",2,"Perfecto."],
 ["I pay with the card.","Pago con la tarjeta.",1,"Mejor «I'll pay by card» o «Card, please»."],
 ["Where is the bathroom?","¿Dónde está el baño?",0,"Eso no responde a la pregunta."]]],
['e',"Your name for the order?","¿Tu nombre para el pedido?",[
 ["It's {NAME}.","Soy {NAME}.",2,"Corto y claro."],
 ["I am {NAME}, nice to meet you very much.","Soy {NAME}, encantado mucho.",1,"Se entiende; en inglés basta «It's {NAME}»."],
 ["Coffee.","Café.",0,"Te piden tu nombre."]]],
['f',"Thanks! It'll be ready in a minute. Have a good one!","¡Gracias! Estará listo en un minuto. ¡Que vaya bien!",[
 ["Thank you! You too.","¡Gracias! Igualmente.",2,"Perfecto."],
 ["Bye.","Adiós.",1,"Vale, pero suena frío."],
 ["Why?","¿Por qué?",0,"No encaja con lo que dice."]]]]},
{id:'surv2',mod:'surv',t:'Perdido en Wynwood',sc:'Pides indicaciones a un desconocido. Si no entiendes, pídelo otra vez.',who:'Persona en la calle',lv:1,nd:[
['a',"Hi! You look a little lost. Can I help you?","¡Hola! Pareces perdido/a. ¿Te ayudo?",[
 ["Yes, please. How do I get to Wynwood?","Sí, por favor. ¿Cómo llego a Wynwood?",2,"Directo y educado."],
 ["Do you speak Spanish?","¿Hablas español?",1,"Pregunta útil, pero aquí ya puedes pedir directamente.","A little! But let's try in English."],
 ["Go away.","Vete.",0,"Muy grosero."]]],
['b',"Sure! Go straight for two blocks, turn left at the light, and it's about a ten-minute walk.","Claro: dos manzanas recto, gira a la izquierda en el semáforo y son diez minutos andando. (rápido)",[
 ["Sorry, could you say that again, more slowly?","Perdón, ¿podría repetirlo más despacio?",2,"Perfecto."],
 ["I'm sorry, I didn't catch that.","Lo siento, no lo he captado.",2,"Muy natural."],
 ["Okay, thanks!","¡Vale, gracias!",0,"Si no lo has entendido, pídelo otra vez antes de irte."]],"No problem."],
['c',"Go straight. Two blocks. Then turn left. Ten minutes on foot.","Recto. Dos manzanas. Luego a la izquierda. Diez minutos a pie.",[
 ["So, straight for two blocks, then left?","Entonces, ¿recto dos manzanas y luego a la izquierda?",2,"Repetir lo que has entendido es la mejor forma de confirmar."],
 ["Left?","¿Izquierda?",1,"Vale, pero confirma todo el camino."],
 ["Where?","¿Dónde?",0,"Demasiado vago."]]],
['d',"Exactly! You can't miss it. There's a lot of colorful street art.","¡Exacto! No tiene pérdida: hay mucho arte urbano de colores.",[
 ["Is it far from here?","¿Está lejos de aquí?",2,"Pregunta útil.","Not really, about ten minutes."],
 ["Thank you so much! You've been very helpful.","¡Muchas gracias! Has sido de gran ayuda.",2,"Perfecto para cerrar."],
 ["Is far.","Está lejos.",0,"Falta «it»: «Is it far?»."]]],
['e',"Enjoy Miami!","¡Disfruta de Miami!",[
 ["Thank you! Have a nice day.","¡Gracias! Que tengas un buen día.",2,"Perfecto."],
 ["Bye.","Adiós.",1,"Vale, pero suena frío."],
 ["No.","No.",0,"No encaja."]]]]},
{id:'air1',mod:'air',t:'Control de pasaportes',sc:'El agente de inmigración te hace las preguntas de siempre.',who:'Agente de inmigración',lv:1,nd:[
['a',"Good afternoon. Passport, please.","Buenas tardes. Pasaporte, por favor.",[
 ["Good afternoon. Here is my passport.","Buenas tardes. Aquí está mi pasaporte.",2,"Perfecto."],
 ["Passport.","Pasaporte.",1,"Mejor con saludo y «here you go»."],
 ["I don't have it.","No lo tengo.",0,"Sin pasaporte no se puede entrar."]]],
['b',"What is the purpose of your visit?","¿Cuál es el motivo de su visita?",[
 ["I'm here on vacation.","Estoy aquí de vacaciones.",2,"Respuesta estándar."],
 ["Vacation.","Vacaciones.",1,"Vale, pero una frase completa es mejor."],
 ["I am tourism.","Soy turismo.",0,"No se dice así. Usa «I'm here on vacation»."]]],
['c',"How long will you be staying?","¿Cuánto tiempo se va a quedar?",[
 ["I'll stay for two weeks.","Me quedaré dos semanas.",2,"Claro."],
 ["Two weeks.","Dos semanas.",1,"Correcto y corto."],
 ["Yesterday.","Ayer.",0,"No responde a la pregunta."]]],
['d',"And where will you be staying?","¿Y dónde se va a alojar?",[
 ["I'm staying at a hotel in Miami Beach.","Me alojo en un hotel en Miami Beach.",2,"Lleva la dirección anotada por si piden más datos."],
 ["At hotel Miami.","En hotel Miami.",1,"En inglés: «at a hotel»."],
 ["I don't know.","No lo sé.",0,"Necesitas saber dónde te alojas."]]],
['e',"Do you have a return ticket?","¿Tiene billete de vuelta?",[
 ["Yes, I fly back on January fifth.","Sí, vuelo de regreso el 5 de enero.",2,"Claro y con fecha."],
 ["Yes, I have.","Sí, tengo.",1,"En inglés: «Yes, I do»."],
 ["No, I'll buy it later.","No, lo compraré luego.",0,"Ten siempre el billete de salida a mano."]]],
['f',"All right. Enjoy your stay in Miami.","Muy bien. Disfrute de su estancia en Miami.",[
 ["Thank you! Have a nice day.","¡Gracias! Que tenga un buen día.",2,"Perfecto."],
 ["Bye.","Adiós.",1,"Vale, pero suena frío."],
 ["See you tomorrow.","Hasta mañana.",0,"No encaja aquí."]]]]},
{id:'air2',mod:'air',t:'Maleta perdida',sc:'Tu maleta no ha llegado y hablas con el mostrador de equipajes.',who:'Empleado/a de equipajes',lv:2,nd:[
['a',"Hello, how can I help you?","Hola, ¿en qué puedo ayudarle?",[
 ["Hi, my suitcase didn't arrive.","Hola, mi maleta no ha llegado.",2,"Claro y directo."],
 ["I need help with my luggage.","Necesito ayuda con mi equipaje.",1,"Vale, pero di qué ha pasado."],
 ["My suitcase is bad.","Mi maleta es mala.",0,"No es lo que quieres decir."]]],
['b',"I'm sorry to hear that. Can I see your baggage claim tag?","Lo siento. ¿Puedo ver su etiqueta de equipaje?",[
 ["Sure, here it is.","Claro, aquí está.",2,"Perfecto."],
 ["What is a tag?","¿Qué es un tag?",1,"Buena idea preguntar; «tag» es la etiqueta."],
 ["No.","No.",0,"Sin la etiqueta es más difícil localizarla."]]],
['c',"What does your suitcase look like?","¿Cómo es su maleta?",[
 ["It's a large black suitcase with a red ribbon.","Es una maleta grande negra con una cinta roja.",2,"Muy útil."],
 ["It is black.","Es negra.",1,"Añade el tamaño o una seña."],
 ["It's my suitcase.","Es mi maleta.",0,"No describe nada."]]],
['d',"Where are you staying? We can deliver it to you.","¿Dónde se aloja? Podemos entregársela allí.",[
 ["I'm staying at a hotel in Miami Beach. Could you deliver it there?","Estoy en un hotel en Miami Beach. ¿Pueden llevarla allí?",2,"Perfecto."],
 ["Hotel Miami Beach.","Hotel Miami Beach.",1,"Mejor una frase completa."],
 ["I don't know.","No lo sé.",0,"Ten la dirección del hotel a mano."]]],
['e',"We'll call you as soon as we find it. What's your phone number?","Le llamaremos en cuanto la encontremos. ¿Cuál es su teléfono?",[
 ["I have a Spanish number. Is that okay?","Tengo un número español. ¿Vale?",2,"Buena pregunta."],
 ["Call me.","Llámeme.",1,"Suena brusco."],
 ["I have not phone.","No tengo teléfono.",0,"Incorrecto y poco útil."]]],
['f',"Don't worry, we'll do our best. Have a good day.","No se preocupe, haremos lo posible. Que tenga un buen día.",[
 ["Thank you for your help.","Gracias por su ayuda.",2,"Perfecto."],
 ["OK.","Vale.",1,"Correcto, pero frío."],
 ["That is not my problem.","Ese no es mi problema.",0,"Muy descortés."]]]]},
{id:'rest1',mod:'rest',t:'Mesa, pedido y cuenta',sc:'Cenas en un restaurante de Miami Beach y pagas con propina.',who:'Camarero/a',lv:1,nd:[
['a',"Hi, welcome! Do you have a reservation?","¡Hola, bienvenidos! ¿Tienen reserva?",[
 ["No, we don't. A table for two, please.","No. Una mesa para dos, por favor.",2,"Claro y educado.","No problem! It'll be about ten minutes."],
 ["Yes, I have.","Sí, tengo.",1,"En inglés: «Yes, we do». Y dar el nombre.","Great, under what name? ...Ah, here it is. Follow me."],
 ["I want eat.","Yo quiero comer.",0,"Falta el verbo: «We'd like a table, please»."]]],
['b',"Here are your menus. Can I get you something to drink?","Aquí tienen las cartas. ¿Les pongo algo de beber?",[
 ["Water, please.","Agua, por favor.",2,"Perfecto."],
 ["Give me water.","Dame agua.",1,"Se entiende, pero suena a orden. Usa «please»."],
 ["I am a water.","Yo soy un agua.",0,"No tiene sentido en inglés."]]],
['c',"Are you ready to order?","¿Están listos para pedir?",[
 ["Yes, I'd like the chicken, please.","Sí, quisiera el pollo, por favor.",2,"Perfecto.","Excellent choice!"],
 ["Could you give us a few more minutes?","¿Nos da unos minutos más?",2,"Muy útil si no estás listo/a.","Of course, take your time. ...Ready now?"],
 ["Chicken.","Pollo.",1,"Mejor una frase educada: «I'd like the chicken, please»."],
 ["Menu is me.","La carta soy yo.",0,"No tiene sentido."]]],
['d',"How is everything tasting?","¿Qué tal está todo?",[
 ["Everything is delicious, thank you.","Todo está delicioso, gracias.",2,"Natural."],
 ["Fine.","Bien.",1,"Vale, pero se puede decir más."],
 ["I am not understand.","No estoy entender.",0,"Mejor: «Sorry, could you repeat that?»."]]],
['e',"Can I get you anything else, or would you like the check?","¿Algo más o prefieren la cuenta?",[
 ["Could we have the check, please?","¿Nos trae la cuenta, por favor?",2,"Perfecto."],
 ["Check.","Cuenta.",1,"Se entiende, pero suena seco."],
 ["The money is yours.","El dinero es tuyo.",0,"No es natural."]]],
['f',"Here you go. Will that be cash or card?","Aquí tiene. ¿Efectivo o tarjeta?",[
 ["Card, please. Is the tip included?","Con tarjeta, por favor. ¿La propina está incluida?",2,"Una pregunta muy útil."],
 ["Card.","Tarjeta.",1,"Añade «please»."],
 ["I don't want to pay.","No quiero pagar.",0,"Eso no se dice."]]],
['g',"No, gratuity isn't included for small groups. You can add it on the receipt.","No, la propina no va incluida en grupos pequeños. Puede añadirla en el recibo.",[
 ["Okay, I'll add twenty percent. Thank you!","Vale, añadiré un 20 %. ¡Gracias!",2,"La propina habitual es 15-20 %."],
 ["Okay.","Vale.",1,"Correcto, pero ¿cuánto vas a dejar?"],
 ["Why is the tip not included?","¿Por qué no está incluida?",0,"Suena a queja: es la norma en EE. UU."]]]]},
{id:'rest2',mod:'rest',t:'Alergia y error en el plato',sc:'Tienes alergia a los frutos secos y te traen un plato equivocado.',who:'Camarero/a',lv:2,nd:[
['a',"Are you ready to order?","¿Están listos para pedir?",[
 ["Yes. I'm allergic to nuts. Does this dish have any?","Sí. Soy alérgico/a a los frutos secos. ¿Este plato lleva?",2,"Dilo siempre antes de pedir."],
 ["I'm allergic.","Soy alérgico/a.",1,"¿A qué? Añade «to nuts»."],
 ["Nuts!","¡Frutos secos!",0,"No se entiende qué quieres."]]],
['b',"Let me check with the kitchen... The sauce has almonds, but I can make it without.","Voy a preguntar a cocina... La salsa lleva almendras, pero puedo pedirla sin.",[
 ["Yes, please make it without nuts.","Sí, por favor, que no lleve frutos secos.",2,"Perfecto."],
 ["Okay, with almonds.","Vale, con almendras.",0,"¡Cuidado! Con alergia, no."],
 ["Without.","Sin.",1,"Mejor una frase completa."]]],
['c',"How would you like your steak? Rare, medium, or well done?","¿Cómo quiere el filete? ¿Poco hecho, medio o muy hecho?",[
 ["Medium, please.","Medio hecho, por favor.",2,"Perfecto."],
 ["Well done, please.","Muy hecho, por favor.",2,"Perfecto."],
 ["A normal one.","Uno normal.",0,"Elige un punto: rare, medium o well done."]]],
['d',"Here you go. Enjoy your meal!","Aquí tiene. ¡Que aproveche!",[
 ["Excuse me, I ordered the fish, not the chicken.","Disculpe, pedí el pescado, no el pollo.",2,"Claro y educado."],
 ["This is wrong.","Esto está mal.",1,"Se entiende, pero suena seco."],
 ["I eat it, thanks.","Lo como, gracias.",0,"Y no era tu plato."]]],
['e',"Oh, I'm so sorry! I'll bring the fish right away.","¡Lo siento mucho! Ahora mismo le traigo el pescado.",[
 ["No problem, thank you.","No pasa nada, gracias.",2,"Perfecto."],
 ["It's okay.","Está bien.",1,"Correcto."],
 ["You are a bad waiter.","Es un mal camarero.",0,"Demasiado duro: se equivocó una vez."]]],
['f',"Here's the check.","Aquí tiene la cuenta.",[
 ["Excuse me, is a service charge included in the bill?","Disculpe, ¿hay cargo por servicio en la cuenta?",2,"Pregunta muy útil."],
 ["Why more money?","¿Por qué más dinero?",0,"Suena brusco."],
 ["Is this tip?","¿Esto es propina?",1,"Se entiende; mejor la frase completa."]]],
['g',"Yes, it's right here: an eighteen percent gratuity is already included.","Sí, aquí: ya está incluida una propina del 18 %.",[
 ["Thank you. Then I won't add more tip.","Gracias. Entonces no añado más propina.",2,"Así no pagas doble."],
 ["OK.","Vale.",1,"Correcto, pero decide qué harás."],
 ["That's too much, I won't pay.","Es demasiado, no pago.",0,"Está en la cuenta, es normal."]]]]},
{id:'trans1',mod:'trans',t:'Un taxi al hotel',sc:'Subes a un taxi y le indicas la dirección.',who:'Taxista',lv:1,nd:[
['a',"Hi! Where to?","¡Hola! ¿A dónde vamos?",[
 ["Hi! Could you take me to this address, please?","¡Hola! ¿Me lleva a esta dirección, por favor?",2,"Enséñale la dirección en el móvil."],
 ["Miami Beach.","Miami Beach.",1,"Mejor con la dirección exacta."],
 ["I go hotel.","Yo voy hotel.",0,"Mejor: «To this hotel, please»."]]],
['b',"Sure thing. Do you mind if I take the highway?","Claro. ¿Le importa que vaya por la autopista?",[
 ["No, that's fine, thanks.","No, perfecto, gracias.",2,"«Do you mind?» se responde «No» si te parece bien."],
 ["Okay.","Vale.",1,"Correcto."],
 ["Yes.","Sí.",0,"«Yes» a «Do you mind?» significa que sí te molesta."]]],
['c',"It'll take about twenty minutes with traffic.","Tardaremos unos veinte minutos con el tráfico.",[
 ["Great. Could you turn on the air conditioning?","Genial. ¿Podría poner el aire acondicionado?",2,"Muy útil en Miami."],
 ["Is hot.","Hace calor.",0,"Mejor: «It's hot»."],
 ["Please, more fast.","Por favor, más rápido.",1,"Se entiende; di «Could you go a bit faster?»."]]],
['d',"Here we are. That'll be thirty-two dollars.","Hemos llegado. Son 32 dólares.",[
 ["Can I pay by card?","¿Puedo pagar con tarjeta?",2,"Pregunta útil.","Sure, tap it here."],
 ["Here you go. Keep the change.","Tome. Quédese con el cambio.",1,"Vale; piensa cuánta propina quieres dar."],
 ["No pay.","No pago.",0,"Siempre se paga el trayecto."]]],
['e',"Have a great day!","¡Que tenga un gran día!",[
 ["You too. Thanks for the ride!","Igualmente. ¡Gracias por el viaje!",2,"Perfecto."],
 ["Bye.","Adiós.",1,"Correcto."],
 ["Why?","¿Por qué?",0,"No encaja."]]]]},
{id:'trans2',mod:'trans',t:'En el autobús al centro',sc:'Coges el autobús y preguntas dónde bajarte.',who:'Conductor/a',lv:2,nd:[
['a',"Where are you headed?","¿A dónde va?",[
 ["Is this the right bus to downtown?","¿Es este el autobús correcto para el centro?",2,"Pregunta perfecta."],
 ["Downtown is where?","¿El centro es dónde?",0,"Orden incorrecto: «Where is downtown?»."],
 ["Hello, bus.","Hola, autobús.",1,"Falta decir a dónde vas."]]],
['b',"Yes, it is. The fare is two dollars and twenty-five cents.","Sí. El billete cuesta 2,25 dólares.",[
 ["Can I pay with my card?","¿Puedo pagar con la tarjeta?",2,"Muy útil."],
 ["I have not money.","No tengo dinero.",0,"Mejor: «I don't have cash»."],
 ["Two dollars.","Dos dólares.",1,"Faltan los 25 centavos."]]],
['c',"Tap your card here. Make sure to ring the bell before your stop.","Pase la tarjeta aquí. Toque el timbre antes de su parada.",[
 ["Could you tell me when we get to Brickell?","¿Podría avisarme cuando lleguemos a Brickell?",2,"Pregunta indirecta educada."],
 ["Okay.","Vale.",1,"Correcto, pero no sabes dónde bajar."],
 ["Bell is where?","¿El timbre es dónde?",0,"Orden incorrecto."]]],
['d',"Sure, I'll let you know. It's about fifteen minutes from here.","Claro, le aviso. Son unos quince minutos desde aquí.",[
 ["Thank you very much.","Muchas gracias.",2,"Perfecto."],
 ["Thanks.","Gracias.",1,"Correcto."],
 ["Fifteen is bad.","Quince es malo.",0,"No se entiende."]]],
['e',"This is your stop, Brickell.","Esta es su parada, Brickell.",[
 ["Thank you! Have a nice day.","¡Gracias! Que tenga un buen día.",2,"Perfecto."],
 ["Bye bye.","Adiós.",1,"Vale."],
 ["No stop.","Sin parada.",0,"No encaja."]]]]},
{id:'emer1',mod:'emer',t:'Me han robado la cartera',sc:'Denuncias un robo ante un agente de policía.',who:'Agente de policía',lv:1,nd:[
['a',"What happened? Are you okay?","¿Qué ha pasado? ¿Está bien?",[
 ["I'm okay, but my wallet was stolen.","Estoy bien, pero me han robado la cartera.",2,"Claro y completo."],
 ["I need help!","¡Necesito ayuda!",1,"Vale, pero di qué ha pasado."],
 ["Nothing happened.","No ha pasado nada.",0,"No es verdad: has venido a denunciar."]]],
['b',"Where did this happen?","¿Dónde ha ocurrido?",[
 ["On Ocean Drive, near the beach.","En Ocean Drive, cerca de la playa.",2,"Dar el lugar es importante."],
 ["I don't know, sorry.","No lo sé, lo siento.",1,"Intenta dar una zona aproximada."],
 ["In Spain.","En España.",0,"No responde a la pregunta."]]],
['c',"What was in the wallet?","¿Qué había en la cartera?",[
 ["My cards, some cash and my ID.","Mis tarjetas, algo de efectivo y mi documento.",2,"Perfecto."],
 ["Everything.","Todo.",1,"Detalla un poco más."],
 ["It is red.","Es roja.",0,"No responde a la pregunta."]]],
['d',"Did you see the person? Can you describe them?","¿Vio a la persona? ¿Puede describirla?",[
 ["No, I didn't see him. It happened very fast.","No, no lo vi. Pasó muy rápido.",2,"Honesto y claro."],
 ["Yes, a man.","Sí, un hombre.",1,"Añade más detalles si los tienes."],
 ["I'm not sure the face I am.","No estoy seguro la cara yo soy.",0,"No se entiende."]]],
['e',"I'll make a report. Do you have travel insurance?","Haré el informe. ¿Tiene seguro de viaje?",[
 ["Yes, I do. I need a copy of the report for my insurance.","Sí. Necesito una copia del informe para mi seguro.",2,"Muy útil."],
 ["Insurance yes.","Seguro sí.",1,"Se entiende; mejor una frase completa."],
 ["What is insurance?","¿Qué es seguro?",0,"Insurance es el seguro de viaje."]]],
['f',"Here's your copy. You should also contact your bank and your consulate.","Aquí tiene su copia. Debería avisar también a su banco y a su consulado.",[
 ["Thank you, officer. I'll do that right away.","Gracias, agente. Lo haré enseguida.",2,"Perfecto."],
 ["OK.","Vale.",1,"Correcto."],
 ["It's not my work.","No es mi trabajo.",0,"Suena grosero."]]]]},
{id:'emer2',mod:'emer',t:'En la farmacia',sc:'Tienes dolor de cabeza y fiebre y hablas con el farmacéutico.',who:'Farmacéutico/a',lv:1,nd:[
['a',"Hi, can I help you?","Hola, ¿puedo ayudarle?",[
 ["Yes, please. I have a headache and a fever.","Sí, por favor. Tengo dolor de cabeza y fiebre.",2,"Perfecto."],
 ["I need a doctor.","Necesito un médico.",1,"Vale, pero aquí puedes pedir consejo primero."],
 ["I am sick head.","Estoy enfermo cabeza.",0,"Mejor: «I have a headache»."]]],
['b',"How long have you had it?","¿Desde cuándo lo tiene?",[
 ["Since this morning.","Desde esta mañana.",2,"Since + punto de inicio."],
 ["For one hour since two weeks.","Por una hora desde dos semanas.",0,"Mezcla for y since."],
 ["A lot.","Mucho.",1,"No contesta a «desde cuándo»."]]],
['c',"Are you allergic to any medication?","¿Es alérgico a algún medicamento?",[
 ["Yes, I'm allergic to penicillin.","Sí, soy alérgico/a a la penicilina.",2,"Dilo siempre."],
 ["No, I'm not.","No.",2,"Correcto si no tienes alergias."],
 ["Allergy is red.","Alergia es roja.",0,"No tiene sentido."]]],
['d',"Okay. This is good for headaches and fever. Take one pill every six hours, with water.","Esto va bien para el dolor de cabeza y la fiebre. Una pastilla cada seis horas, con agua.",[
 ["Sorry, could you say that again, slowly?","Perdón, ¿puede repetirlo despacio?",2,"Con medicación, asegúrate de entender."],
 ["Okay, thanks.","Vale, gracias.",1,"Si no estás seguro/a de la dosis, pregunta."],
 ["I take all.","Me lo tomo todo.",0,"Peligroso: respeta la dosis."]],"Of course. One pill. Every six hours. With water."],
['e',"One pill every six hours. Do you understand?","Una pastilla cada seis horas. ¿Lo ha entendido?",[
 ["One pill every six hours. Thank you!","Una pastilla cada seis horas. ¡Gracias!",2,"Repetir confirma que lo has entendido."],
 ["Six pills.","Seis pastillas.",0,"No es lo que ha dicho."],
 ["Every six.","Cada seis.",1,"Falta decir cuántas."]]],
['f',"If you don't feel better in two days, see a doctor.","Si no mejora en dos días, vaya al médico.",[
 ["I will. How much is it?","Lo haré. ¿Cuánto es?",2,"Perfecto."],
 ["OK.","Vale.",1,"Correcto."],
 ["No doctor.","Sin médico.",0,"Si no mejora, hay que ir."]]]]},
{id:'shop1',mod:'shop',t:'Probarse una camiseta',sc:'Buscas una camiseta, te la pruebas y pagas.',who:'Dependiente/a',lv:1,nd:[
['a',"Hi! Can I help you find anything?","¡Hola! ¿Le ayudo a encontrar algo?",[
 ["Hi! I'm looking for a T-shirt.","¡Hola! Busco una camiseta.",2,"Claro."],
 ["I'm just looking, thanks.","Solo estoy mirando, gracias.",2,"Muy habitual y educado.","Sure, let me know if you need anything!"],
 ["No English.","Sin inglés.",0,"Mejor: «Sorry, I don't speak much English»."]]],
['b',"What size are you?","¿Qué talla es?",[
 ["I think a medium. Can I try it on?","Creo que M. ¿Puedo probármela?",2,"Perfecto."],
 ["Medium.","M.",1,"Correcto, pero añade la petición."],
 ["I am medium big small.","Soy mediano grande pequeño.",0,"No se entiende."]]],
['c',"Of course. The fitting rooms are right over there. How does it fit?","Claro, los probadores están ahí. ¿Qué tal le queda?",[
 ["It's a bit big. Do you have a smaller size?","Me queda un poco grande. ¿Tiene una talla menor?",2,"Muy útil."],
 ["Is big.","Es grande.",1,"Mejor: «It's big»."],
 ["It is very fit.","Es muy fit.",0,"«Fit» no se usa así."]]],
['d',"Here's a small. That's thirty-nine ninety-nine.","Aquí tiene una S. Son 39,99.",[
 ["Okay, I'll take it. Do you take credit cards?","Vale, me la quedo. ¿Aceptan tarjetas?",2,"Perfecto."],
 ["Too expensive. Bye.","Demasiado cara. Adiós.",1,"Es una opción, pero sé más amable."],
 ["I pay nothing.","No pago nada.",0,"No es posible."]]],
['e',"Sure. Would you like a bag?","Claro. ¿Quiere una bolsa?",[
 ["Yes, please. And can I get a receipt?","Sí, por favor. ¿Y me da el recibo?",2,"Perfecto."],
 ["Yes.","Sí.",1,"Correcto."],
 ["No bag no receipt no.","No bolsa no recibo no.",0,"No se entiende."]]]]},
{id:'hotel1',mod:'hotel',t:'Check-in y aire acondicionado',sc:'Haces el check-in, preguntas por el resort fee y avisas de un problema.',who:'Recepcionista',lv:2,nd:[
['a',"Welcome to the hotel! Do you have a reservation?","¡Bienvenido/a! ¿Tiene reserva?",[
 ["Yes, I have a reservation under my name, {NAME}.","Sí, tengo una reserva a nombre de {NAME}.",2,"Perfecto."],
 ["Yes, I have.","Sí, tengo.",1,"Mejor «Yes, I do» y el nombre."],
 ["I sleep here.","Yo duermo aquí.",0,"No es lo que quieres decir."]]],
['b',"Can I see your passport and a credit card, please?","¿Me enseña el pasaporte y una tarjeta de crédito?",[
 ["Sure, here you are. Is there a resort fee?","Claro, aquí tiene. ¿Hay resort fee?",2,"Pregunta muy útil.","Yes, it's thirty dollars per night, plus tax. It includes the pool and beach towels."],
 ["Here.","Aquí.",1,"Correcto, pero algo seco."],
 ["Passport no, card yes.","Pasaporte no, tarjeta sí.",0,"Piden ambos."]]],
['c',"Breakfast is from seven to ten. Check-out is at eleven.","El desayuno es de siete a diez. El check-out es a las once.",[
 ["Thank you. Is breakfast included?","Gracias. ¿El desayuno está incluido?",2,"Pregunta útil."],
 ["What?","¿Qué?",0,"Suena brusco. Di «Sorry, could you repeat that?»."],
 ["Late check-out?","¿Check-out tarde?",1,"Mejor: «Could I get a late check-out?»."]]],
['d',"Front desk, how can I help you?","Recepción, ¿en qué puedo ayudarle?",[
 ["Hi, the air conditioning doesn't work in room 512.","Hola, el aire acondicionado no funciona en la 512.",2,"Dar el número de habitación."],
 ["Room is hot.","La habitación está caliente.",1,"Se entiende, pero di el problema."],
 ["Help help.","Ayuda ayuda.",0,"No se entiende."]]],
['e',"I'm sorry about that. I'll send someone right away.","Lo siento. Envío a alguien ahora mismo.",[
 ["Thank you. Could I also have extra towels?","Gracias. ¿Podría darme también toallas?",2,"Aprovecha para pedirlo."],
 ["Okay.","Vale.",1,"Correcto."],
 ["Hurry up!","¡Dese prisa!",0,"Muy descortés."]]],
['f',"Thanks for staying with us. How was your stay?","Gracias por alojarse. ¿Qué tal su estancia?",[
 ["It was great, thank you. Could you call me a taxi?","Fue genial, gracias. ¿Me llama un taxi?",2,"Perfecto."],
 ["Good.","Bien.",1,"Correcto."],
 ["I stayed.","Me quedé.",0,"No responde."]]]]},
{id:'soc1',mod:'soc',t:'Charla en la playa',sc:'Conversas con una persona simpática y le pides recomendaciones.',who:'Persona en la playa',lv:2,nd:[
['a',"Hey! Great weather today, huh?","¡Hola! Qué buen tiempo hace, ¿eh?",[
 ["Yes, it's amazing! I love Miami.","¡Sí, es increíble! Me encanta Miami.",2,"Natural."],
 ["Yes.","Sí.",1,"Correcto, pero corto."],
 ["I am hot weather.","Yo soy tiempo caliente.",0,"No tiene sentido."]]],
['b',"Are you here on vacation?","¿Estás de vacaciones?",[
 ["Yes, I'm here on vacation with a friend. I'm from Spain.","Sí, estoy de vacaciones con una amiga. Soy de España.",2,"Perfecto."],
 ["Yes. Spain.","Sí. España.",1,"Correcto, pero mejor frases."],
 ["I from Spain am.","Yo de España soy.",0,"Orden incorrecto."]]],
['c',"Spain, nice! How long are you here for?","¡España, qué bien! ¿Cuánto tiempo estáis?",[
 ["Two weeks. What do you recommend doing here?","Dos semanas. ¿Qué recomiendas hacer aquí?",2,"Genial para seguir hablando."],
 ["Two weeks.","Dos semanas.",1,"Correcto."],
 ["Is long.","Es largo.",0,"No responde a la pregunta."]]],
['d',"You should check out Wynwood for the street art, and Little Havana for the food!","¡Tenéis que ir a Wynwood por el arte urbano y a Little Havana por la comida!",[
 ["That sounds great! Could you take a picture of us, please?","¡Suena genial! ¿Nos haces una foto, por favor?",2,"Natural."],
 ["OK.","Vale.",1,"Correcto, pero muestra interés."],
 ["Where is Little?","¿Dónde es Little?",0,"Es «Little Havana»."]]],
['e',"Sure! Smile! Here you go.","¡Claro! ¡Sonreíd! Aquí tenéis.",[
 ["Thank you so much! It was nice talking to you.","¡Muchas gracias! Ha sido un placer hablar contigo.",2,"Perfecto."],
 ["Thanks. Bye.","Gracias. Adiós.",1,"Correcto."],
 ["Give me the phone.","Dame el teléfono.",0,"Muy brusco."]]]]},
{id:'money1',mod:'money',t:'Pedir en el bar y la propina',sc:'Pides en un bar, pagas con el móvil y decides la propina.',who:'Barman / barwoman',lv:2,nd:[
['a',"What can I get you?","¿Qué te pongo?",[
 ["Could I have a mojito and a water, please?","¿Me pones un mojito y un agua, por favor?",2,"Perfecto."],
 ["Mojito.","Mojito.",1,"Correcto, pero algo seco."],
 ["I am a mojito.","Yo soy un mojito.",0,"No tiene sentido."]]],
['b',"Sure. Do you want to pay now or open a tab?","Claro. ¿Pagas ahora o abro una cuenta?",[
 ["I'll pay now, please. Can I pay with my phone?","Pago ahora. ¿Puedo pagar con el móvil?",2,"Muy útil."],
 ["Open the tab.","Abre la cuenta.",1,"Se entiende; mejor «Could you open a tab?»."],
 ["Tab is cash?","¿Tab es efectivo?",0,"No tiene sentido."]]],
['c',"That's sixteen dollars. Tap your phone here.","Son 16 dólares. Acerca el móvil aquí.",[
 ["Sure. Here you go.","Claro. Aquí tienes.",2,"Perfecto."],
 ["Is much.","Es mucho.",0,"No es lo que quieres decir."],
 ["Okay.","Vale.",1,"Correcto."]]],
['d',"There's a suggested tip on the screen: fifteen, twenty, or twenty-five percent.","En la pantalla hay una propina sugerida: 15, 20 o 25 %.",[
 ["I'll choose twenty percent. Thank you!","Elijo el 20 %. ¡Gracias!",2,"Es lo habitual."],
 ["I don't know what to press.","No sé qué pulsar.",1,"Pregunta: «Which button is twenty percent?»."],
 ["No tip. I don't like tips.","Sin propina. No me gustan.",0,"En EE. UU. no dejarla es mal visto salvo mal servicio."]]],
['e',"Thank you! Enjoy your night.","¡Gracias! Que disfrutes de la noche.",[
 ["Thanks, you too!","¡Gracias, igualmente!",2,"Perfecto."],
 ["Bye.","Adiós.",1,"Correcto."],
 ["Give me more.","Dame más.",0,"Muy brusco."]]]]}
];
