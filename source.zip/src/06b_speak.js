/* ===== HABLAR: reconocimiento de voz del navegador (si existe) o autoevaluación ===== */
const SRC=()=>window.SpeechRecognition||window.webkitSpeechRecognition||null;
const wnorm=t=>String(t).toLowerCase().replace(/[’']/g,'').replace(/[^a-z0-9 ]+/g,' ').split(/\s+/).filter(Boolean);
/* forma canónica: números a cifras, contracciones plegadas, A/C, wifi, 911, sin muletillas (please, a, an, the) para no penalizar variantes */
const NUMW={zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19,twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90,first:1,second:2,third:3,fourth:4,fifth:5,sixth:6,seventh:7,eighth:8,ninth:9,tenth:10};
function numtok(ws){const o=[];for(let i=0;i<ws.length;i++){let w=ws[i];const m=w.match(/^(\d+)(st|nd|rd|th)$/);if(m)w=m[1];
  const sp=w.match(/^([a-z])(\d+)$/);if(sp){o.push(sp[1],sp[2]);continue}
  if(w==='second'&&ws[i-1]&&/^(a|one|just|wait|hold|give|me|for)$/.test(ws[i-1]))o.push(w);
  else if(NUMW[w]!==undefined){let v=NUMW[w];if(v>=20&&v%10===0&&ws[i+1]&&NUMW[ws[i+1]]>=1&&NUMW[ws[i+1]]<=9){v+=NUMW[ws[i+1]];i++}o.push(String(v))}else o.push(w)}return o}
const FOLD=[[/\bdo not\b/g,'dont'],[/\bdoes not\b/g,'doesnt'],[/\bdid not\b/g,'didnt'],[/\bcannot\b/g,'cant'],[/\bcan not\b/g,'cant'],[/\bis not\b/g,'isnt'],[/\bare not\b/g,'arent'],[/\bwas not\b/g,'wasnt'],[/\bhas not\b/g,'hasnt'],[/\bhave not\b/g,'havent'],[/\bwill not\b/g,'wont'],[/\bwould not\b/g,'wouldnt'],[/\bcould not\b/g,'couldnt'],
 [/\bi am\b/g,'im'],[/\byou are\b/g,'youre'],[/\bwe are\b/g,'were'],[/\bit is\b/g,'its'],[/\bwhat is\b/g,'whats'],[/\bwhere is\b/g,'wheres'],[/\bthat is\b/g,'thats'],[/\bhere is\b/g,'heres'],[/\bthere is\b/g,'theres'],[/\bhow is\b/g,'hows'],[/\bi will\b/g,'ill'],[/\bi have\b/g,'ive'],[/\bi would\b/g,'id'],[/\bwe would\b/g,'wed'],[/\blet us\b/g,'lets'],
 [/\bcheck out\b/g,'checkout'],[/\bwi fi\b/g,'wifi'],[/\bstomach ache\b/g,'stomachache'],[/\b(?:a c|ac)\b/g,'air conditioning'],[/\bair condition(?:er|ing)?\b/g,'air conditioning'],[/\b9 1 1\b/g,'911']];
const DROPW=new Set(['please','a','an','the']);
function cw(t){let s=numtok(wnorm(t)).join(' ');FOLD.forEach(f=>{s=s.replace(f[0],f[1])});return s.split(' ').filter(w=>w&&!DROPW.has(w))}
const NEGW=new Set(['not','no','never','nothing','none','dont','doesnt','didnt','cant','isnt','arent','wasnt','hasnt','havent','wont','wouldnt','couldnt']);
const OPP=[['left','right'],['on','off'],['more','less'],['smaller','bigger'],['slowly','quickly'],['spanish','english'],['window','aisle'],['buy','sell'],['arrive','leave'],['open','close'],['up','down'],['much','little'],['many','few'],['before','after'],['early','late']];
/* guardas: misma polaridad (negación), mismos números y sin palabras opuestas */
function guardOK(vw,hw){const vn=vw.some(w=>NEGW.has(w)),hn=hw.some(w=>NEGW.has(w));if(vn!==hn)return false;
  const nums=a=>a.filter(w=>/^\d+$/.test(w)&&w!=='1').sort().join(',');if(nums(vw)!==nums(hw))return false;
  for(const o of OPP){const va=vw.includes(o[0]),vb=vw.includes(o[1]),ha=hw.includes(o[0]),hb=hw.includes(o[1]);if((va&&!vb&&hb&&!ha)||(vb&&!va&&ha&&!hb))return false}return true}
function wscore(target,heard){const t=cw(target),h=cw(heard);if(!t.length)return 0;if(!guardOK(t,h))return 0;const hh=h.slice();let hit=0;t.forEach(w=>{const i=hh.indexOf(w);if(i>=0){hit++;hh.splice(i,1)}});
  if(t.length<=2&&h.length>t.length+3)return hit/t.length*.5;return hit/t.length}
function speakScore(target,heard){return wscore(target,heard)}
const ALT_MAP={},NOTE_MAP={};
const altOf=en=>ALT_MAP[wnorm(en).join(' ')]||[];
const noteOf=en=>NOTE_MAP[wnorm(en).join(' ')]||'';
/* ¿vale lo oído? la frase o cualquiera de sus variantes (≥75 % de palabras; ≤2 palabras: todas). main=true si coincide con la frase de la app */
function speakOK(q,heard){let best=-1,bi=0,ok=false;[q.ans].concat(q.alt||altOf(q.ans)).forEach((v,i)=>{const n=cw(v).length,s=wscore(v,heard);if(s>best){best=s;bi=i}if(s>=(n<=4?1:.75))ok=true});return{ok:ok,main:ok&&bi===0,score:Math.max(best,0)}}
/* nota de registro: la específica de la frase o una regla general (could/can, please) */
function speakNote(q,heard){const n=noteOf(q.ans);if(n)return n;const h=wnorm(heard),t=wnorm(q.ans);
  if(t.includes('could')&&(h.includes('can')||h.includes('want')))return'«Could» es más cortés que «Can»: al pedir algo a un desconocido suena mejor.';
  if(t.includes('please')&&!h.includes('please'))return'Con «please» suena más amable.';return'Tu versión también se entiende bien.'}
function speakQ(p){return{k:'speak',kind:'Habla',blk:'speak',key:'p:'+p.id,es:p.es,ans:p.en,alt:altOf(p.en),e:p.en+' · '+p.es}}
function speakQs(ps,n){const short=ps.filter(p=>p.en.split(' ').length<=8);return shuf(short.length>=n?short:ps).slice(0,n).map(speakQ)}
function speakHtml(q){const sr=!!SRC();
  return'<div class="prompt">'+esc(q.es)+'</div><p class="muted">Dilo en inglés, en voz alta.</p>'+
  (sr?'<button class="btn block" id="mic" data-a="mic">🎤 Pulsa y habla</button><p class="muted" id="spkfb" style="min-height:24px;text-align:center"></p>':'<p class="muted">Tu navegador no reconoce voz: dilo tú, mira la frase y valórate.</p>')+
  '<div id="rv"></div><div class="row" style="margin-top:10px"><button class="btn sec grow" data-a="showen">👀 Ver y escuchar la frase</button><button class="btn sec" data-a="sayno">Saltar</button></div>'}
ACT.showen=()=>{if(SE.locked)return;micOff();const q=SE.cur;const r=$('#rv');if(!r)return;
  r.innerHTML='<div class="card" style="text-align:center"><b>'+esc(q.ans)+'</b> '+spk(q.ans)+'</div><div class="row"><button class="btn grow" data-a="sayok">✅ Lo he dicho bien</button><button class="btn sec grow" data-a="sayno">🔁 No me sale</button></div>';say(q.ans)};
ACT.sayok=()=>{if(SE.locked)return;micOff();finishQ(true,SE.cur)};
ACT.sayno=()=>{if(SE.locked)return;micOff();finishQ(false,SE.cur)};
/* El micro solo está abierto mientras se graba la frase: se corta al oír, al pasar de pregunta, tras 8 s, al minimizar o cambiar de pestaña */
let REC=null,RECT=0;
function micOff(){clearTimeout(RECT);const r=REC;REC=null;if(SE)SE.listening=false;if(r){r.onresult=r.onerror=r.onend=null;try{r.stop()}catch(e){}try{r.abort()}catch(e){}setTimeout(()=>{try{r.abort()}catch(e){}},300)}const m=$('#mic');if(m)m.textContent='🎤 Pulsa y habla'}
if(document.addEventListener)document.addEventListener('visibilitychange',()=>{if(document.hidden)micOff()});
if(window.addEventListener)window.addEventListener('pagehide',micOff);
const _quit=ACT.quit;if(_quit)ACT.quit=function(){micOff();return _quit.apply(this,arguments)};
ACT.mic=()=>{if(SE.locked)return;if(SE.listening){micOff();return}const SR=SRC();if(!SR){toast('Tu navegador no oye voz: usa «Ver la frase»');return}
  const q=SE.cur;let r;try{r=new SR()}catch(e){toast('No se pudo abrir el micrófono');return}
  r.lang='en-US';r.interimResults=false;r.continuous=false;r.maxAlternatives=3;SE.listening=true;REC=r;let got=false;
  const b=$('#mic');if(b)b.textContent='🎙️ Te escucho… (pulsa para parar)';
  RECT=setTimeout(()=>{if(REC===r){const f=$('#spkfb');micOff();if(f&&!got)f.textContent='No te he oído. Pulsa y habla otra vez.'}},8000);
  r.onresult=e=>{got=true;const alts=[];try{for(const a of e.results[0])alts.push(a.transcript)}catch(x){}micOff();
    let best=alts[0]||'',ok=false,main=false,bs=-1;
    alts.forEach(t=>{const o=speakOK(q,t);if(o.ok&&(!ok||(o.main&&!main))){ok=true;main=o.main;best=t}else if(!ok&&o.score>bs){bs=o.score;best=t}});
    if(SE.cur!==q||SE.locked)return;
    if(ok){let m='Te he entendido: «'+best+'».';if(!main)m+=' Vale, es correcto. Pero la frase de la app es mejor: «'+q.ans+'». '+speakNote(q,best);finishQ(true,q,m)}
    else{const f=$('#spkfb');if(f)f.innerHTML='Te he oído: «'+esc(best)+'». Prueba otra vez o mira la frase.'}};
  r.onerror=e=>{got=true;micOff();toast(e&&(e.error==='not-allowed'||e.error==='service-not-allowed')?'Permite el micrófono en el navegador':'No te he oído, prueba otra vez')};
  r.onend=()=>{if(REC===r)micOff();if(!got&&!SE.locked){const f=$('#spkfb');if(f)f.textContent='No te he oído. Pulsa y habla otra vez.'}};
  try{r.start()}catch(e){micOff()}};
function startTalk(mod){const qs=speakQs(modPh(MOD[mod]),6);startSession(qs,{per:12,bonus:10,title:'Habla · '+MOD[mod].n,onDone:r=>{if(r.tot>=3){prog(mod).talk=1;save()}}})}
ACT.speakp=()=>startSession(speakQs(allPh(),8),{per:12,bonus:15,title:'Hablar'});

Object.keys(ALT_RAW).forEach(k=>{ALT_MAP[wnorm(k).join(' ')]=ALT_RAW[k]});Object.keys(NOTE_RAW).forEach(k=>{NOTE_MAP[wnorm(k).join(' ')]=NOTE_RAW[k]});
