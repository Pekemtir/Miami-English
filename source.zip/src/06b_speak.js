/* ===== HABLAR: reconocimiento de voz del navegador (si existe) o autoevaluación ===== */
const SRC=()=>window.SpeechRecognition||window.webkitSpeechRecognition||null;
const wnorm=t=>String(t).toLowerCase().replace(/[’']/g,'').replace(/[^a-z0-9 ]+/g,' ').split(/\s+/).filter(Boolean);
function speakScore(target,heard){const t=wnorm(target),h=wnorm(heard).slice();if(!t.length)return 0;let hit=0;t.forEach(w=>{const i=h.indexOf(w);if(i>=0){hit++;h.splice(i,1)}});return hit/t.length}
function speakQ(p){return{k:'speak',kind:'Habla',blk:'speak',key:'p:'+p.id,es:p.es,ans:p.en,e:p.en+' · '+p.es}}
function speakQs(ps,n){const short=ps.filter(p=>p.en.split(' ').length<=8);return shuf(short.length>=n?short:ps).slice(0,n).map(speakQ)}
function speakHtml(q){const sr=!!SRC();
  return'<div class="prompt">'+esc(q.es)+'</div><p class="muted">Dilo en inglés, en voz alta.</p>'+
  (sr?'<button class="btn block" id="mic" data-a="mic">🎤 Pulsa y habla</button><p class="muted" id="spkfb" style="min-height:24px;text-align:center"></p>':'<p class="muted">Tu navegador no reconoce voz: dilo tú, mira la frase y valórate.</p>')+
  '<div id="rv"></div><div class="row" style="margin-top:10px"><button class="btn sec grow" data-a="showen">👀 Ver y escuchar la frase</button><button class="btn sec" data-a="sayno">Saltar</button></div>'}
ACT.showen=()=>{if(SE.locked)return;const q=SE.cur;const r=$('#rv');if(!r)return;
  r.innerHTML='<div class="card" style="text-align:center"><b>'+esc(q.ans)+'</b> '+spk(q.ans)+'</div><div class="row"><button class="btn grow" data-a="sayok">✅ Lo he dicho bien</button><button class="btn sec grow" data-a="sayno">🔁 No me sale</button></div>';say(q.ans)};
ACT.sayok=()=>{if(SE.locked)return;finishQ(true,SE.cur)};
ACT.sayno=()=>{if(SE.locked)return;finishQ(false,SE.cur)};
ACT.mic=()=>{if(SE.locked||SE.listening)return;const SR=SRC();if(!SR){toast('Tu navegador no oye voz: usa «Ver la frase»');return}
  const q=SE.cur;let r;try{r=new SR()}catch(e){toast('No se pudo abrir el micrófono');return}
  r.lang='en-US';r.interimResults=false;r.maxAlternatives=3;SE.listening=true;let got=false;
  const b=$('#mic');if(b)b.textContent='🎙️ Te escucho…';
  const stop=()=>{SE.listening=false;const m=$('#mic');if(m)m.textContent='🎤 Pulsa y habla'};
  r.onresult=e=>{got=true;stop();const alts=[];try{for(const a of e.results[0])alts.push(a.transcript)}catch(x){}
    let best=alts[0]||'',bs=-1;alts.forEach(t=>{const s=speakScore(q.ans,t);if(s>bs){bs=s;best=t}});
    if(SE.cur!==q||SE.locked)return;const need=wnorm(q.ans).length<=2?1:.75;
    if(bs>=need){finishQ(true,q,'Te he entendido: «'+best+'».')}
    else{const f=$('#spkfb');if(f)f.innerHTML='Te he oído: «'+esc(best)+'». Prueba otra vez o mira la frase.'}};
  r.onerror=e=>{got=true;stop();toast(e&&(e.error==='not-allowed'||e.error==='service-not-allowed')?'Permite el micrófono en el navegador':'No te he oído, prueba otra vez')};
  r.onend=()=>{stop();if(!got&&!SE.locked){const f=$('#spkfb');if(f)f.textContent='No te he oído. Pulsa y habla otra vez.'}};
  try{r.start()}catch(e){stop()}};
function startTalk(mod){const qs=speakQs(modPh(MOD[mod]),6);startSession(qs,{per:12,bonus:10,title:'Habla · '+MOD[mod].n,onDone:r=>{if(r.tot>=3){prog(mod).talk=1;save()}}})}
ACT.speakp=()=>startSession(speakQs(allPh(),8),{per:12,bonus:15,title:'Hablar'});
