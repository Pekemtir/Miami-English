(function(){
/* ===== NÚCLEO: utilidades, estado, voz, XP, insignias ===== */
const $=(s,r)=>(r||document).querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const rnd=n=>Math.floor(Math.random()*n);
const shuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=rnd(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
const pick=(a,n)=>shuf(a).slice(0,n);
const one=a=>a[rnd(a.length)];
const nfc=s=>String(s).normalize('NFC').toLowerCase().replace(/[’`´]/g,"'").replace(/[¿?¡!.,;:«»"()·$]/g,'').replace(/-/g,' ').replace(/\s+/g,' ').trim();
const norm=s=>nfc(s).normalize('NFD').replace(/[̀-ͯ]/g,'').normalize('NFC');
const pad=n=>String(n).padStart(2,'0');
const today=()=>{const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
const yest=()=>{const d=new Date(Date.now()-864e5);return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
const KEY='miami-english-v1';
const DEF={v:1,xp:0,streak:0,last:'',day:{d:'',xp:0},goal:30,prof:null,test:null,plan:null,sug:null,les:{},prog:{},weak:{},m:{},srs:{},badges:{},fin:null,
  stat:{ok:0,tot:0,sims:0},set:{voice:true,theme:'auto',rate:.95,fast:false,voiceName:''},seen:{}};
let S;
function load(){try{const r=localStorage.getItem(KEY);S=r?Object.assign({},DEF,JSON.parse(r)):JSON.parse(JSON.stringify(DEF))}catch(e){S=JSON.parse(JSON.stringify(DEF))}
  ['prog','weak','m','srs','badges','seen','les'].forEach(k=>{if(!S[k]||typeof S[k]!=='object')S[k]={}});
  S.stat=Object.assign({ok:0,tot:0,sims:0},S.stat);S.set=Object.assign({voice:true,theme:'auto',rate:.95,fast:false,voiceName:''},S.set);S.day=S.day||{d:'',xp:0}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
load();
function applyTheme(){let t=S.set.theme;const r=document.documentElement;if(t==='auto'){try{t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'}catch(e){t='dark'}}r.setAttribute('data-theme',t)}
try{matchMedia('(prefers-color-scheme: light)').addEventListener('change',()=>{if(S.set.theme==='auto')applyTheme()})}catch(e){}
function toast(m){const t=document.createElement('div');t.className='toast';t.textContent=m;document.body.appendChild(t);setTimeout(()=>t.remove(),2600)}
function streakNow(){return(S.last===today()||S.last===yest())?S.streak:0}
function dayXP(){return S.day.d===today()?S.day.xp:0}
function addXP(n){if(!n)return;const t=today();
  if(S.day.d!==t)S.day={d:t,xp:0};
  const before=S.day.xp;S.day.xp+=n;S.xp+=n;
  if(S.last!==t){S.streak=(S.last===yest())?S.streak+1:1;S.last=t}
  if(before<S.goal&&S.day.xp>=S.goal)toast('🎯 ¡Objetivo diario conseguido!');
  checkBadges();save()}
/* ----- voz: inglés americano de preferencia ----- */
let CAV=null,VOICES=[];
const isUS=v=>/^en[-_]US/i.test(v.lang);
const isEn=v=>/^en([-_]|$)/i.test(v.lang);
function pickVoice(){try{VOICES=speechSynthesis.getVoices()||[];const en=VOICES.filter(isEn);
  let v=S&&S.set&&S.set.voiceName?VOICES.find(x=>x.name===S.set.voiceName):null;
  if(!v){const us=en.filter(isUS);v=us.find(x=>/premium|enhanced|natural|neural|online/i.test(x.name))||us[0]||en.find(x=>/premium|enhanced|natural|neural|online/i.test(x.name))||en[0]||null}
  CAV=v||null}catch(e){}}
try{pickVoice();speechSynthesis.onvoiceschanged=pickVoice}catch(e){}
function speakable(t){let x=String(t).replace(/<[^>]+>/g,' ');
  x=x.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F1E6}-\u{1F1FF}️]/gu,' ');
  x=x.replace(/\$\s?(\d+(?:\.\d+)?)/g,'$1 dollars').replace(/%/g,' percent');
  x=x.replace(/[«»"“”]/g,'').replace(/\s*[—–→]\s*/g,', ').replace(/…/g,', ').replace(/[+=]/g,' ').replace(/\s*\/\s*/g,', ');
  return x.replace(/[’`´]/g,"'").replace(/\s+/g,' ').trim()}
function say(t,rate){if(!S.set.voice)return;try{speechSynthesis.cancel();if(!CAV)pickVoice();const u=new SpeechSynthesisUtterance(speakable(t));u.lang=CAV?CAV.lang:'en-US';if(CAV)u.voice=CAV;u.rate=rate||S.set.rate||.95;speechSynthesis.speak(u)}catch(e){}}
const spk=(t)=>'<button class="spk" data-a="say" data-v="'+esc(t)+'" aria-label="Escuchar">🔊</button>';
const fastRate=()=>S.set.fast?1.08:.95;
/* ----- insignias ----- */
const BADGES=[
['b1','🌴','Primer paso','Completa un paso del plan',()=>Object.values(S.prog).some(p=>p.learn||p.prac||p.sim)],
['m1','🛫','Módulo listo','Completa un módulo entero',()=>Object.values(S.prog).some(p=>p.done)],
['m3','🧳','Tres módulos','3 módulos completos',()=>Object.values(S.prog).filter(p=>p.done).length>=3],
['m5','🎫','Mínimos hechos','Completa los 5 módulos imprescindibles',()=>typeof MIN_DONE==='function'&&MIN_DONE()],
['s3','🔥','3 días seguidos','Racha de 3 días',()=>streakNow()>=3],
['s7','🔥','Semana','Racha de 7 días',()=>streakNow()>=7],
['x100','⭐','100 XP','Suma 100 XP',()=>S.xp>=100],
['x500','🌟','500 XP','Suma 500 XP',()=>S.xp>=500],
['x2000','✨','2.000 XP','Suma 2.000 XP',()=>S.xp>=2000],
['sim1','🎬','Primera escena','Completa una simulación',()=>S.stat.sims>=1],
['sim5','🎭','Actor','Completa 5 simulaciones',()=>S.stat.sims>=5],
['ft','🏁','Test final','Haz el test final',()=>!!S.fin]];
function checkBadges(){BADGES.forEach(b=>{if(!S.badges[b[0]]&&b[4]()){S.badges[b[0]]=today();toast(b[1]+' Insignia: '+b[2])}})}
/* ----- dominio por frase (0-4) y repetición espaciada ----- */
const mast=k=>S.m[k]||0;
const bump=(k,ok)=>{S.m[k]=Math.max(0,Math.min(4,mast(k)+(ok?1:-1)));try{srsMark(k,ok)}catch(e){}};
const INTV=[1,3,7,21,45];
const dnum=()=>{const d=new Date();return Math.floor((d.getTime()-d.getTimezoneOffset()*6e4)/864e5)};
