/* ===== PANTALLAS (2/3): plan, módulos, estudio y lecciones ===== */
V.plan=()=>{
  if(!S.prof)return'<h1>Mi plan</h1><div class="card"><p>Primero cuéntame sobre ti para montar el plan.</p></div><button class="btn block" data-a="onb">Empezar</button>';
  if(!S.test)return'<h1>Mi plan</h1><div class="card"><p>Haz el test de nivel y generaré tu plan.</p></div><button class="btn block" data-a="tintro">Hacer el test</button>';
  if(!S.plan)return'<h1>Mi plan</h1><button class="btn block" data-a="mkplan">Generar mi plan</button>';
  const P=S.plan,items=P.items;
  let h='<h1>Mi plan</h1><div class="card goal">'+ring(planPct())+'<div class="grow"><b>Nivel '+LVN[LV()]+' · '+P.weeks+' semanas</b><div class="muted">'+Math.round(P.used)+' min de plan · presupuesto '+Math.round(P.budget)+' min</div></div></div>';
  if(P.tight)h+='<div class="card ch"><b>⏱ Tu tiempo es justo</b><p class="muted">Los 5 módulos imprescindibles ya ocupan casi todo. Prioriza esos y deja lo demás como opcional.</p></div>';
  const wk=weakFlags();const wl=[];if(wk.oral)wl.push('comprensión oral');if(wk.gram)wl.push('gramática');if(wk.vocab)wl.push('vocabulario');
  if(wl.length)h+='<div class="card"><b>🎯 Refuerzo según tu test:</b> '+wl.join(', ')+'. El plan incluye más práctica en eso.</div>';
  let w=0;items.forEach((it,i)=>{if(it.w!==w){w=it.w;h+='<h2>Semana '+w+'</h2>'}const L=itemLabel(it);const d=itemDone(it);h+=row(L.ic,esc(L.t),esc(L.s)+' · '+it.min+' min','stepgo',i,d?'done':'')});
  const inPlan={};items.forEach(i=>{if(i.mod)inPlan[i.mod]=1});
  const opt=MODS.filter(m=>!inPlan[m.id]);
  if(opt.length)h+='<h2>Opcionales</h2>'+opt.map(m=>row(m.ic,esc(m.n),'No cabe en tu tiempo, pero puedes hacerlo','mod',m.id)).join('');
  h+='<div class="row" style="margin-top:16px"><button class="btn sec sm" data-a="mkplan">🔄 Regenerar plan</button><button class="btn sec sm" data-a="rtest">🧪 Rehacer test</button><button class="btn sec sm" data-a="onb">✏️ Cambiar mis datos</button></div>';
  if(MIN_DONE()&&!S.fin)h+='<div class="card ch" style="margin-top:14px"><b>Ya tienes los 5 módulos imprescindibles</b><p class="muted">Puedes hacer el test final cuando quieras.</p><button class="btn block" data-a="ftest">🏁 Test final</button></div>';
  return h};
ACT.ftest=()=>startFinalTest();
ACT.stepgo=i=>{const it=S.plan&&S.plan.items[+i];if(!it)return;
  if(it.t==='learn')return go('learn',it.mod,true);
  if(it.t==='prac')return startPrac(it.mod);
  if(it.t==='sim')return go('sim',it.sim,true);
  if(it.t==='drill')return startDrill(it.mod);
  if(it.t==='talk')return startTalk(it.mod);
  if(it.t==='gr'||it.t==='b1')return go('lesson',it.les,true);
  if(it.t==='final')return startFinalTest()};
V.sim=simIntro;
/* ----- módulo ----- */
V.mod=id=>{const m=MOD[id],p=prog(id);const ps=modPh(m);
  let h='<h1>'+m.ic+' '+esc(m.n)+'</h1><p class="muted">'+(m.min?'⭐ Imprescindible':'Opcional')+' · '+ps.length+' frases a tu nivel ('+LVN[LV()]+')</p>';
  h+='<div class="card"><b>Al acabar podrás…</b><ul>'+m.goals.map(g=>'<li>'+esc(g)+'</li>').join('')+'</ul></div>';
  if(S.sug&&S.sug.mod===id)h+=sugCard(id,S.sug.skill);
  h+=row('📖','1 · Aprende','Frases con audio y consejos de Miami','go2',id+':learn',p.learn?'done':'');
  h+=row('🎯','2 · Practica','Mejor resultado: '+(p.prac?p.prac+' %':'—')+' (aprobado 70 %)','prac',id,p.prac>=70?'done':'');
  simsOf(id).forEach((s,i)=>{h+=row('🎬','3 · '+esc(s.t),'Mejor: '+starsTxt(p.sims[s.id]||0),'sim',s.id,p.sims[s.id]?'done':'')});
  h+=row('🎧','Escucha rápida','Acento americano a velocidad real'+(p.drill?' · mejor '+p.drill+' %':''),'drill',id,p.drill>=70?'done':'');
  if(p.done)h+='<div class="card ch"><b>🎉 Módulo completado</b></div>';
  return h};
ACT.mod=id=>go('mod',id,true);
ACT.go2=v=>{const a=v.split(':');go(a[1],a[0],true)};
ACT.prac=id=>startPrac(id);ACT.drill=id=>startDrill(id);
function startPrac(mod){const ps=modPh(MOD[mod]);const n=Math.min(14,Math.max(8,ps.length+3));
  startSession(mixQs(ps,n),{per:8,bonus:15,title:'Práctica · '+MOD[mod].n,onDone:r=>{const pr=prog(mod),p=Math.round(r.acc*100);pr.prac=Math.max(pr.prac,p);addSk(mod,r.blk);
      if(modDone(mod))pr.done=true;const w=weakest(mod);S.sug=w?{mod:mod,skill:w}:null;save();checkBadges()},
    extra:r=>{const w=weakest(mod);return w?'<div class="card ch" style="margin-top:12px"><b>💪 Tu punto más flojo aquí: '+SKN[w]+'</b><div class="row"><button class="btn sm" data-a="reinf" data-v="'+mod+':'+w+'">Reforzar ahora</button><button class="btn sec sm" data-a="sugx">Seguir</button></div></div>':(r.acc>=.85?'<div class="card ch" style="margin-top:12px"><b>🔥 Muy bien. Puedes pasar a la simulación.</b></div>':'')}})}
function startDrill(mod){if(!S.set.voice){toast('🔇 Activa el sonido para la escucha');return}const ps=modPh(MOD[mod]);const qs=mixQs(ps,10,['listen']);
  startSession(qs,{per:8,bonus:10,title:'Escucha rápida · '+MOD[mod].n,onDone:r=>{const pr=prog(mod);pr.drill=Math.max(pr.drill||0,Math.round(r.acc*100));save()}})}
/* ----- aprender frases de un módulo ----- */
V.learn=id=>{const m=MOD[id];const lv=LV();
  let h='<h1>'+m.ic+' '+esc(m.n)+'</h1><p class="muted">Toca 🔊 para oír (🐢 despacio). Toca el castellano para verlo.</p>';
  h+='<h2>Consejos de Miami</h2>'+m.tips.map(t=>'<div class="tip">'+t+'</div>').join('');
  h+='<h2>Frases</h2>';
  const mk=p=>'<div class="ex">'+spk(p.en)+'<button class="spk" data-a="slow" data-v="'+esc(p.en)+'" aria-label="Despacio">🐢</button><div class="grow"><b>'+esc(p.en)+'</b><div class="muted blur" data-a="reveal">'+esc(p.es)+'</div></div><span class="chipx">'+LVN[p.lv]+'</span></div>';
  h+='<div class="card">'+m.ph.filter(p=>p.lv<=lv).map(mk).join('')+'</div>';
  const hard=m.ph.filter(p=>p.lv>lv);
  if(hard.length)h+='<details><summary>Frases de más nivel ('+hard.length+')</summary><div class="card">'+hard.map(mk).join('')+'</div></details>';
  h+='<button class="btn block" data-a="flashm" data-v="'+id+'">🃏 Repasar con tarjetas</button><button class="btn sec block" style="margin-top:10px" data-a="learned" data-v="'+id+'">'+(prog(id).learn?'✓ Ya estudiado':'Marcar como estudiado (+10 XP)')+'</button>';
  return h};
ACT.reveal=(v,el)=>{if(el)el.classList.toggle('on')};
ACT.flashm=id=>{const ps=modPh(MOD[id]);startSession(shuf(ps).map(p=>({k:'flash',kind:'Tarjetas',ca:p.en,es:p.es,em:MOD[id].ic,key:'p:'+p.id})),{per:3,bonus:10,title:'Tarjetas · '+MOD[id].n})};
ACT.learned=id=>{const p=prog(id);if(!p.learn){p.learn=true;addXP(10)}save();toast('✅ Guardado');up()};
/* ----- lecciones (B1 y refuerzo A1-A2) ----- */
V.lesson=id=>{const l=B1M[id]||GRM[id];if(!l)return'<p>No encuentro la lección.</p>';const isB1=!!B1M[id];
  let h='<h1>'+l.ic+' '+esc(l.n)+'</h1><p class="muted">'+esc(l.es)+'</p><div class="chipx">'+(isB1?'Nivel '+(l.lvl||'B1'):'Refuerzo A1-A2')+'</div><div class="chipx">'+l.min+' min</div>';
  h+='<div class="card"><b>Objetivos</b><ul>'+l.goals.map(g=>'<li>'+esc(g)+'</li>').join('')+'</ul><p class="muted" style="margin:0">Referencia: '+esc(l.mcer)+'</p></div>';
  l.st.forEach(s=>{h+='<h2>'+esc(s.t)+'</h2><div class="card">'+s.h+'</div><div class="card">'+s.ex.map(e=>'<div class="ex">'+spk(e[0])+'<div class="grow"><b>'+esc(e[0])+'</b><div class="muted">'+esc(e[1])+'</div></div></div>').join('')+'</div>'});
  const best=S.les[id]&&S.les[id].best;
  h+='<button class="btn block" data-a="lpractice" data-v="'+id+'">✏️ Practicar ('+l.q.length+' ejercicios)</button>'+(best!=null?'<p class="muted" style="text-align:center">Mejor resultado: '+best+' %</p>':'');
  return h};
ACT.lesson=id=>go('lesson',id,true);
ACT.lpractice=id=>{const l=B1M[id]||GRM[id];startSession(lessonQs(l),{per:8,bonus:15,title:l.n,onDone:r=>{const p=Math.round(r.acc*100);const o=S.les[id]||{};S.les[id]={best:Math.max(o.best||0,p),date:today()};save();checkBadges()}})};
