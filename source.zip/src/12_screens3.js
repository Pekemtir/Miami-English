/* ===== PANTALLAS (3/3): práctica, simulaciones, frases, perfil y referencias ===== */
function srsCard(){const n=srsDue().length;return n?'<button class="lrow" data-a="srs" style="border-color:var(--yel)"><span class="ic">🧠</span><span class="grow"><small>Repaso espaciado</small><b>'+n+' frases para hoy</b><small>Vuelven a los 1, 3, 7, 21 y 45 días</small></span><span>▶</span></button>':''}
ACT.srs=()=>{const w=srsDue().slice(0,10);if(!w.length){toast('Nada que repasar hoy. ¡Buen trabajo!');return}startSession(mixQs(w,10,S.set.voice?['tr','rev','listen']:['tr','rev']),{per:8,bonus:10,title:'Repaso espaciado'})};
ACT.fastl=()=>{if(!S.set.voice){toast('🔇 Activa el sonido para la escucha');return}startSession(mixQs(allPh(),12,['listen']),{per:8,bonus:10,title:'Escucha rápida'})};
ACT.daily=()=>{const first=!S.seen['dc'+today()];startSession(mixQs(allPh(),10).concat(cultQs(2)),{per:8,bonus:first?30:10,title:'Mix del día',onDone:r=>{if(r.acc>=.6){S.seen['dc'+today()]=1;save()}}})};
ACT.weak=()=>{const ks=shuf(Object.keys(S.weak)).slice(0,12);const qs=ks.map(keyToQ).filter(Boolean);if(!qs.length){toast('No tienes frases débiles');return}startSession(qs,{per:8,title:'Frases débiles'})};
ACT.cult=()=>startSession(cultQs(8),{per:8,bonus:10,title:'Cultura práctica'});
V.practice=()=>{let h='<h1>Práctica</h1>'+srsCard();
  h+=row('🎤','Hablar','Di frases en voz alta (micrófono si tu navegador lo permite)','speakp');
  h+=row('🎧','Escucha rápida','Frases a velocidad real con acento americano','fastl');
  h+=row('⚡','Mix del día','10 preguntas de todo lo que llevas','daily');
  const nw=Object.keys(S.weak).length;h+=row('💪','Frases débiles',nw+' pendientes','weak');
  h+=row('🧭','Cultura práctica','Propinas, impuestos, 911… (8 preguntas)','cult');
  h+=row('🎬','Simulaciones','Conversaciones reales, '+SIMS.length+' escenas','go','sims');
  h+=row('📘','Temario B1 (repaso)','18 lecciones · unas 3 h de gramática, léxico y funciones','go','b1list');h+=row('📗','Temario B2 (repaso)','22 lecciones · unas 4,5 h de nivel avanzado','go','b2list');
  h+=row('🧱','Refuerzo A1-A2','6 mini-lecciones de gramática básica','go','grs');
  h+=row('🧪','Test de nivel','Repítelo cuando quieras','rtest');
  h+=row('🏁','Test final','Compara con tu nivel inicial'+(S.fin?' · último: '+S.fin.score+' %':''),'ftest');
  h+=row('📚','Temario y referencias','Qué cubre la app y con qué se ha contrastado','go','refs');
  return h};
V.sims=()=>{let h='<h1>🎬 Simulaciones</h1><p class="muted">Conversaciones con respuestas a elegir. Sin conexión.</p>';
  MODS.forEach(m=>{const l=simsOf(m.id);if(l.length){h+='<h2>'+m.ic+' '+esc(m.n)+'</h2>'+l.map(s=>row('🎬',esc(s.t),'Mejor: '+starsTxt(simBest(s.id))+' · '+LVN[s.lv]+'+','sim',s.id,simBest(s.id)?'done':'')).join('')}});return h};
V.b2list=()=>{let h='<h1>📗 Curso B2</h1><p class="muted">Gramática, léxico y funciones del nivel avanzado. Recomendado desde B1 sólido.</p>';
  h+=B2.map(l=>{const b=S.les[l.id]&&S.les[l.id].best;return row(l.ic,esc(l.n),esc(l.es)+(b!=null?' · mejor '+b+' %':''),'lesson',l.id,b>=70?'done':'')}).join('');return h};
V.b1list=()=>{let h='<h1>📘 Curso B1</h1><p class="muted">Gramática, léxico y funciones del nivel intermedio. Recomendado desde A2.</p>';
  h+=B1.map(l=>{const b=S.les[l.id]&&S.les[l.id].best;return row(l.ic,esc(l.n),esc(l.es)+(b!=null?' · mejor '+b+' %':''),'lesson',l.id,b>=70?'done':'')}).join('');return h};
V.grs=()=>{let h='<h1>🧱 Refuerzo A1-A2</h1><p class="muted">Gramática básica para viajar.</p>';
  h+=GR.map(l=>{const b=S.les[l.id]&&S.les[l.id].best;return row(l.ic,esc(l.n),esc(l.es)+(b!=null?' · mejor '+b+' %':''),'lesson',l.id,b>=70?'done':'')}).join('');return h};
/* ----- frases ----- */
const KEY30=[['surv',[0,1,2,3,5,6,10]],['air',[0,1,2,3]],['rest',[0,3,5,6,8]],['trans',[2,3,6,7]],['emer',[0,1,2,4,5]],['hotel',[0,3]],['shop',[0]],['soc',[0]],['money',[0]]];
const key30=()=>KEY30.reduce((a,x)=>a.concat(x[1].map(i=>MOD[x[0]].ph[i]).filter(Boolean)),[]);
let PF={mod:'all',q:''};
V.phrases=()=>{let h='<h1>Frases</h1><p class="muted">Tu libro de frases, sin conexión.</p><button class="btn block" data-a="go" data-v="card">📇 Tarjeta de 30 frases clave</button><input id="pq" class="fld" style="margin-top:12px" type="search" placeholder="Buscar en inglés o castellano" value="'+esc(PF.q)+'">';
  h+='<div class="pills"><button class="pill'+(PF.mod==='all'?' on':'')+'" data-a="pfm" data-v="all">Todas</button>'+MODS.map(m=>'<button class="pill'+(PF.mod===m.id?' on':'')+'" data-a="pfm" data-v="'+m.id+'">'+m.ic+'</button>').join('')+'</div><div id="pres">'+phList()+'</div>';return h};
function phList(){const q=norm(PF.q);let ps=PF.mod==='all'?MODS.reduce((a,m)=>a.concat(m.ph),[]):MOD[PF.mod].ph;if(q)ps=ps.filter(p=>norm(p.en).indexOf(q)>=0||norm(p.es).indexOf(q)>=0);
  if(!ps.length)return'<p class="muted">Sin resultados.</p>';
  return'<div class="card">'+ps.slice(0,80).map(p=>'<div class="hit">'+spk(p.en)+'<b>'+esc(p.en)+'</b><span class="es">'+esc(p.es)+'</span></div>').join('')+'</div>'+(ps.length>80?'<p class="muted">Mostrando 80 de '+ps.length+'. Afina la búsqueda.</p>':'')}
ACT.pfm=v=>{PF.mod=v;showCur()};
V.card=()=>{const ps=key30();return'<h1>📇 30 frases clave</h1><p class="muted">Pantallazo, copia o imprímela para llevarla en el viaje.</p><div class="card">'+ps.map(p=>'<div class="hit">'+spk(p.en)+'<b>'+esc(p.en)+'</b><span class="es">'+esc(p.es)+'</span></div>').join('')+'</div><div class="row"><button class="btn sm" data-a="printc">🖨️ Imprimir</button><button class="btn sec sm" data-a="copyc">📋 Copiar texto</button></div>'};
ACT.printc=()=>{try{window.print()}catch(e){}};
ACT.copyc=()=>{const t=key30().map(p=>p.en+' — '+p.es).join('\n');try{navigator.clipboard.writeText(t).then(()=>toast('Copiado'),()=>toast('No se pudo copiar'))}catch(e){toast('No se pudo copiar')}};
/* ----- yo: perfil, ajustes, copia de seguridad ----- */
V.me=()=>{const P=S.prof;let h='<h1>Yo</h1>';
  if(P)h+='<div class="card"><b>'+esc(P.name)+'</b><div class="muted">Nivel '+LVN[LV()]+(S.test&&S.test.skipped?' (estimado)':'')+' · '+(GOALS.filter(g=>g[0]===P.goal)[0]||['','','']) [2]+' · '+P.weeks+' semanas · '+P.mins+' min/día</div><div class="row" style="margin-top:8px"><button class="btn sec sm" data-a="onb">Editar datos</button><button class="btn sec sm" data-a="rtest">Rehacer test</button></div></div>';
  else h+='<button class="btn block" data-a="onb">Empezar</button>';
  if(S.test&&S.test.cat&&Object.keys(S.test.cat).length)h+='<div class="card"><b>Habilidades (test inicial)</b>'+catBars(S.test.cat)+'</div>';
  if(S.fin)h+='<div class="card"><b>Test final</b><p>'+LVN[S.fin.lv]+' · '+S.fin.score+' % ('+S.fin.date+')</p></div>';
  h+='<h2>Insignias</h2><div class="badges">'+BADGES.map(b=>'<span class="badge'+(S.badges[b[0]]?'':' off')+'" title="'+esc(b[3])+'">'+b[1]+' '+esc(b[2])+'</span>').join('')+'</div>';
  h+='<h2>Ajustes</h2><div class="card"><div class="setrow"><span class="ic">🔊</span><div class="grow"><b>Sonido</b><div class="muted">Voz en inglés del navegador</div></div><button class="btn sec sm" data-a="svoice">'+(S.set.voice?'Activado':'Silencio')+'</button></div>'+
   '<div class="setrow" style="margin-top:10px"><span class="ic">🐢</span><div class="grow"><b>Velocidad normal</b></div><div class="pills" style="margin:0">'+[[.8,'Lenta'],[.95,'Normal'],[1.1,'Rápida']].map(x=>'<button class="pill'+(S.set.rate===x[0]?' on':'')+'" data-a="srate" data-v="'+x[0]+'">'+x[1]+'</button>').join('')+'</div></div>'+
   '<div class="setrow" style="margin-top:10px"><span class="ic">🇺🇸</span><div class="grow"><b>Escucha a ritmo real</b><div class="muted">Acento americano más rápido en escucha y simulaciones</div></div><button class="btn sec sm" data-a="sfast">'+(S.set.fast?'Sí':'No')+'</button></div>'+
   '<div class="setrow" style="margin-top:10px"><span class="ic">🎙️</span><div class="grow"><b>Voz</b><select id="vsel" class="fld">'+voiceOpts()+'</select></div></div>'+
   '<div class="setrow" style="margin-top:10px"><span class="ic">🎨</span><div class="grow"><b>Tema</b></div><div class="pills" style="margin:0">'+[['auto','Auto'],['dark','Noche'],['light','Día']].map(x=>'<button class="pill'+(S.set.theme===x[0]?' on':'')+'" data-a="stheme" data-v="'+x[0]+'">'+x[1]+'</button>').join('')+'</div></div>'+
   '<div class="setrow" style="margin-top:10px"><span class="ic">🎯</span><div class="grow"><b>Objetivo diario</b></div><div class="pills" style="margin:0">'+[20,30,50].map(n=>'<button class="pill'+(S.goal===n?' on':'')+'" data-a="sgoal" data-v="'+n+'">'+n+' XP</button>').join('')+'</div></div></div>';
  h+='<h2>Mis datos</h2><div class="card"><p class="muted">Tu progreso solo está en este dispositivo. Haz copia para no perderlo.</p><div class="row"><button class="btn sec sm" data-a="bkcopy">📋 Copiar copia de seguridad</button><button class="btn sec sm" data-a="bkshow">Importar</button></div><div id="bkbox"></div><button class="btn sec sm" style="margin-top:10px" data-a="reset">🗑️ Borrar todo</button></div>';
  h+=row('📚','Temario y referencias','Cobertura B1, fuentes y licencias','go','refs')+'<a class="lrow" href="https://pekemtir.github.io/The-English-Way/" target="_blank" rel="noopener" style="text-decoration:none;color:inherit"><span class="ic">🌱</span><span class="grow"><b>The English Way</b><small>Curso gratuito A1 + A2 completo, por si quieres más base</small></span><span>↗</span></a>';
  return h};
function voiceOpts(){try{pickVoice()}catch(e){}const en=(VOICES||[]).filter(isEn);if(!en.length)return'<option>Voz del sistema</option>';
  return'<option value="">Automática (inglés de EE. UU.)</option>'+en.map(v=>'<option value="'+esc(v.name)+'"'+(S.set.voiceName===v.name?' selected':'')+'>'+esc(v.name)+' ('+esc(v.lang)+')</option>').join('')}
ACT.svoice=()=>{S.set.voice=!S.set.voice;if(!S.set.voice){try{speechSynthesis.cancel()}catch(e){}}save();showCur()};
ACT.srate=v=>{S.set.rate=+v;save();showCur();say('Hello! Welcome to Miami.')};
ACT.sfast=()=>{S.set.fast=!S.set.fast;save();showCur()};
ACT.stheme=v=>{S.set.theme=v;save();applyTheme();showCur()};
ACT.sgoal=v=>{S.goal=+v;save();showCur()};
ACT.bkcopy=()=>{const t=JSON.stringify(S);try{navigator.clipboard.writeText(t).then(()=>toast('Copia en el portapapeles'),()=>{ACT.bkshow()})}catch(e){ACT.bkshow()}};
ACT.bkshow=()=>{const b=$('#bkbox');if(b)b.innerHTML='<textarea id="bkt" class="fld" placeholder="Pega aquí tu copia de seguridad" rows="4">'+esc(JSON.stringify(S))+'</textarea><button class="btn sm" data-a="bkimp" style="margin-top:8px">Importar lo pegado</button>'};
ACT.bkimp=()=>{const t=$('#bkt');if(!t)return;try{const o=JSON.parse(t.value);if(!o||typeof o!=='object'||o.v!==1)throw 0;localStorage.setItem(KEY,JSON.stringify(o));load();applyTheme();toast('✅ Copia importada');go('home')}catch(e){toast('La copia no es válida')}};
ACT.reset=()=>{if(confirm('¿Borrar todo tu progreso y tus datos de este dispositivo?')){try{localStorage.removeItem(KEY)}catch(e){}load();applyTheme();NAV=[];go('home')}};
