/* ===== PLAN PERSONALIZADO: reglas que ensamblan módulos según perfil, nivel, objetivo y tiempo ===== */
const GOALS=[['tour','🏖️','Viaje de turismo'],['work','💼','Trabajo'],['study','🎓','Estudios'],['def','🙂','Solo defenderme']];
const FEARS=[['air','🛬','Aeropuerto y migración'],['rest','🍽️','Restaurantes y propinas'],['trans','🚕','Taxi, Uber y direcciones'],['emer','🚑','Urgencias'],['shop','🛍️','Compras'],['hotel','🏨','Hotel'],['soc','🥂','Charlar con gente'],['money','💵','Dinero e impuestos'],['surv','🆘','No entender lo que me dicen']];
const GOAL_EXTRAS={tour:['hotel','shop','soc','money'],work:['soc','hotel','money','shop'],study:['soc','shop','money','hotel'],def:['shop','hotel','money','soc']};
const MOD_GR={surv:'g2',air:'g2',rest:'g2',trans:'g5',emer:'g3',shop:'g6',hotel:'g2',soc:'g3',money:'g6'};
function MIN_DONE(){return MINS.every(id=>(S.prog[id]||{}).done)}
const prog=id=>S.prog[id]||(S.prog[id]={learn:false,prac:0,sims:{},drill:0,done:false,sk:{}});
function simsOf(id){return SIMS.filter(s=>s.mod===id)}
function modDone(id){const p=prog(id);return !!(p.learn&&p.prac>=70&&simsOf(id).every(s=>p.sims[s.id]))}
function weeksLeft(){const P=S.prof||{};return Math.max(1,Math.min(16,P.weeks||6))}
function itemDone(it){
  if(it.t==='learn')return !!prog(it.mod).learn;
  if(it.t==='prac')return prog(it.mod).prac>=70;
  if(it.t==='sim')return !!prog(it.mod).sims[it.sim];
  if(it.t==='drill')return prog(it.mod).drill>=70;
  if(it.t==='gr'||it.t==='b1')return !!(S.les&&S.les[it.les]&&S.les[it.les].best>=70);
  if(it.t==='final')return !!S.fin;
  return false}
function buildPlan(){
  const P=S.prof||{};const lv=LV();const wk=weakFlags();
  const days=P.days||5,mins=P.mins||15,weeks=weeksLeft();
  const budget=weeks*days*mins;const fears=P.fears||[];const goal=P.goal||'tour';
  const items=[];
  const modItems=id=>{const a=[{t:'learn',mod:id,min:5},{t:'prac',mod:id,min:6}];
    simsOf(id).forEach(s=>a.push({t:'sim',mod:id,sim:s.id,min:5}));
    if(wk.oral&&MOD[id].min)a.push({t:'drill',mod:id,min:4});return a};
  const order=MINS.slice().sort((a,b)=>{if(a==='surv')return -1;if(b==='surv')return 1;const fa=fears.indexOf(a)>=0?0:1,fb=fears.indexOf(b)>=0?0:1;return fa-fb||MINS.indexOf(a)-MINS.indexOf(b)});
  const grLessons=()=>{let g=[];if(lv===1)g=['g1','g2','g3','g4','g5','g6'];else if(lv===2&&wk.gram)g=['g3','g4','g5'];else if(wk.gram)g=['g3','g4'];return g};
  const gr=grLessons();let grI=0;
  order.forEach((id,idx)=>{modItems(id).forEach(i=>items.push(i));
    if(gr[grI]&&(idx>=1||lv===1)){const l=GRM[gr[grI++]];items.push({t:'gr',les:l.id,min:l.min})}});
  while(grI<gr.length){const l=GRM[gr[grI++]];items.push({t:'gr',les:l.id,min:l.min})}
  let used=items.reduce((a,i)=>a+i.min,0);
  const reserve=Math.round(budget*.12)+12;
  const extras=MODS.filter(m=>!m.min).map(m=>m.id).sort((a,b)=>{const fa=fears.indexOf(a)>=0?0:1,fb=fears.indexOf(b)>=0?0:1;if(fa!==fb)return fa-fb;return (GOAL_EXTRAS[goal]||[]).indexOf(a)-(GOAL_EXTRAS[goal]||[]).indexOf(b)});
  extras.forEach(id=>{const its=modItems(id);const cost=its.reduce((a,i)=>a+i.min,0);if(used+cost<=budget-reserve){its.forEach(i=>items.push(i));used+=cost}});
  /* lecciones del curso B1 si hay hueco (nivel A2 en adelante) */
  if(lv>=2){const cap=lv===3?B1.length:(lv===4?2:4);let c=0;B1.forEach(l=>{if(c<cap&&used+l.min<=budget-reserve){items.push({t:'b1',les:l.id,min:l.min});used+=l.min;c++}})}
  /* lecciones del curso B2 (solo nivel B2) */
  if(lv>=4){let c=0;B2.forEach(l=>{if(used+l.min<=budget-reserve){items.push({t:'b1',les:l.id,min:l.min});used+=l.min;c++}})}
  items.push({t:'final',min:12});used+=12;
  let cum=0;const per=days*mins;
  items.forEach(i=>{i.w=Math.floor(cum/per)+1;cum+=i.min});
  S.plan={items:items,created:today(),budget:budget,used:used,tight:used>budget,lv:lv,weeks:weeks};
  save();return S.plan}
function nextItem(){if(!S.plan)return null;return S.plan.items.find(i=>!itemDone(i))||null}
function planPct(){if(!S.plan)return 0;const it=S.plan.items;return Math.round(it.filter(itemDone).length/it.length*100)}
function itemLabel(it){
  if(it.t==='learn')return{ic:MOD[it.mod].ic,t:'Aprende · '+MOD[it.mod].n,s:'Frases, audio y consejos'};
  if(it.t==='prac')return{ic:'🎯',t:'Practica · '+MOD[it.mod].n,s:'Sesión de preguntas (aprobado 70 %)'};
  if(it.t==='sim'){const s=SIMS.find(x=>x.id===it.sim);return{ic:'🎬',t:'Simulación · '+s.t,s:MOD[it.mod].n}}
  if(it.t==='drill')return{ic:'🎧',t:'Escucha rápida · '+MOD[it.mod].n,s:'Acento americano a velocidad real'};
  if(it.t==='gr'){const l=GRM[it.les];return{ic:l.ic,t:'Gramática · '+l.n,s:l.es}}
  if(it.t==='b1'){const l=B1M[it.les];return{ic:l.ic,t:(l.lvl||'B1')+' · '+l.n,s:l.es}}
  return{ic:'🏁',t:'Test final',s:'Compara tu nivel con el del principio'}}
/* ----- adaptación: punto débil de un módulo y recomendaciones ----- */
const SKN={oral:'comprensión oral',vocab:'vocabulario y frases',struct:'estructura de las frases'};
function weakest(id){const sk=prog(id).sk||{};let w=null,wa=1;['oral','vocab','struct'].forEach(k=>{const s=sk[k];if(s&&s.tot>=3){const a=s.ok/s.tot;if(a<.75&&a<wa){wa=a;w=k}}});return w}
function avgPrac(){const d=MODS.filter(m=>prog(m.id).prac>0);if(d.length<2)return 0;return Math.round(d.reduce((a,m)=>a+prog(m.id).prac,0)/d.length)}
function bonusRec(){if(avgPrac()<85)return null;const left=MODS.filter(m=>!m.min&&!modDone(m.id));return left.length?left:null}
function addSk(id,blk){const sk=prog(id).sk=prog(id).sk||{};Object.keys(blk||{}).forEach(k=>{if(k==='oral'||k==='vocab'||k==='struct'){const s=sk[k]||(sk[k]={ok:0,tot:0});s.ok+=blk[k].ok;s.tot+=blk[k].tot;if(s.tot>40){s.ok=Math.round(s.ok*.6);s.tot=Math.round(s.tot*.6)}}})}
