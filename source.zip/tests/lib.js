const fs=require('fs'),path=require('path'),vm=require('vm');const {makeEnv,fire}=require('./dom.js');
const INDEX=path.join(__dirname,'..','index.html');
const HOOK='window.__T={get S(){return S},get SE(){return SE},get SM(){return SM},get CUR(){return CUR},get TS(){return TS},ACT:ACT,V:V,go:go,showCur:showCur,TB:TB,speakScore:speakScore,startTalk:startTalk,IOSBR:IOSBR,MODS:MODS,MOD:MOD,PH:PH,SIMS:SIMS,B1:B1,B2:B2,B2M:B2M,GR:GR,GRM:GRM,B1M:B1M,CULT:CULT,buildPlan:buildPlan,itemDone:itemDone,nextItem:nextItem,modPh:modPh,allPh:allPh,mixQs:mixQs,KINDS:KINDS,lessonQs:lessonQs,cultQs:cultQs,key30:key30,LV:LV,prog:prog,modDone:modDone,weakFlags:weakFlags,estimate:estimate,checkType:checkType,BADGES:BADGES,srsDue:srsDue,load:load,MINS:MINS,simsOf:simsOf,KEY:KEY,trQ:trQ,revQ:revQ,listenQ:listenQ,clozeQ:clozeQ,buildQ:buildQ,dnum:dnum};';
const fails=[];let checks=0;
const ok=(c,m)=>{checks++;if(!c){fails.push(m);console.log('  ✗ FALLO:',m)}};
const section=t=>console.log('\n== '+t);
function boot(store){let html=fs.readFileSync(INDEX,'utf8');if(!/\}\)\(\);\s*<\/script>/.test(html))throw new Error('sin cierre IIFE');
  html=html.replace(/\}\)\(\);\s*<\/script>/,HOOK+'})();</script>');
  const env=makeEnv(html,store||{});const code=html.match(/<script>([\s\S]*)<\/script>/)[1];
  try{vm.runInContext(code,env.ctx)}catch(e){console.log('ERROR AL ARRANCAR',e.stack);fails.push('arranque: '+e.message)}
  const app={env,T:env.ctx.__T,store:env.store,
    $:s=>env.body.querySelector(s),$$:s=>env.body.querySelectorAll(s),
    click(el){if(!el)throw new Error('click sobre null');fire(env,el,'click')},
    clickA(a,v){const sel='[data-a="'+a+'"]'+(v!==undefined?'[data-v="'+v+'"]':'');const el=env.body.querySelector(sel);if(!el)throw new Error('no existe '+sel+' en: '+app.text().slice(0,120));fire(env,el,'click')},
    has(a,v){return !!env.body.querySelector('[data-a="'+a+'"]'+(v!==undefined?'[data-v="'+v+'"]':''))},
    type(sel,txt){const el=env.body.querySelector(sel);if(!el)throw new Error('no existe '+sel);el.value=txt;fire(env,el,'input')},
    text(){return env.body.querySelector('#app').textContent},
    inSession(){return env.body.classList.contains('in-session')},
    tab(v){fire(env,env.body.querySelector('.tab[data-v="'+v+'"]'),'click')}};
  return app}
/* Responde la pregunta actual: good=true acierta, false falla */
function answerQ(app,good){const SE=app.T.SE;const q=SE.cur;
  if(q.k==='speak'){app.clickA('showen');app.clickA(good?'sayok':'sayno');const nx0=app.$('#nx');if(nx0)app.click(nx0);return}
  if(q.k==='flash'){app.clickA('flip');app.clickA(good?'fyes':'fno');return}
  if(q.k==='build'){const all=q.tok.concat(q.extra||[]);const want=good?q.ans.split(' '):['zzz'];const used=new Set();
    want.forEach(w=>{const b=app.$$('#bk .wt').find(x=>x.textContent===w&&!x.classList.contains('gone')&&!used.has(x));if(b){used.add(b);app.click(b)}});
    if(!app.$('#ck').disabled)app.clickA('check');else app.clickA('check');}
  else if(q.k==='choice'){const opts=app.$$('.opt');const t=opts.find(b=>(b.dataset.v===q.ans)===good);if(!t)throw new Error('sin opción para '+q.p);app.click(t)}
  else{const tb=app.$('#tb');if(!tb)throw new Error('sin campo de texto');tb.value=good?(q.alts||[q.ans])[(q.alts||[0]).length>1?1:0]:'zzz';app.clickA('check')}
  const nx=app.$('#nx');if(nx)app.click(nx)}
/* Juega una sesión entera. pol: función(i)->bool */
function playSession(app,pol){let n=0;const seen=[];while(app.T.SE&&app.inSession()&&n<400){const SE=app.T.SE;if(!SE.cur&&n>0)break;seen.push(SE.cur);answerQ(app,pol(n,SE.cur));n++;if(!app.T.SE)break;if(app.T.SE&&!app.inSession())break;if(app.$('[data-a="done"]'))break}
  return{n:n,seen:seen}}
module.exports={boot,answerQ,playSession,ok,section,fails,checks:()=>checks,fire};
