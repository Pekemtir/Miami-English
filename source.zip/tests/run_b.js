const L=require('./lib.js');const {boot,playSession,ok,section}=L;const {onboard,guard}=require('./run_a.js');
function playSim(app,mode){const T=app.T;let turns=0,slipped={},g=0;
  while(T.SM&&app.inSession()&&g++<80){const SM=T.SM,nd=SM.nodes[SM.cur];const idx=nd.o.map((o,i)=>i);let pick;
    if(mode==='best')pick=idx.find(i=>nd.o[i][2]===2);
    else if(mode==='slip'){const z=idx.find(i=>nd.o[i][2]===0&&!SM.used[SM.cur+':'+i]);pick=(!slipped[SM.cur]&&z!==undefined)?z:idx.find(i=>nd.o[i][2]===2);slipped[SM.cur]=1}
    else{const o1=idx.find(i=>nd.o[i][2]===1);pick=(o1!==undefined)?o1:idx.find(i=>nd.o[i][2]===2)}
    app.clickA('simpick',String(pick));const nx=app.$('#nx');if(!nx)throw new Error('sin hoja de feedback');app.click(nx);if(nd.o[pick][2]>0)turns++}
  return turns}
function setup(lv){const app=boot({});onboard(app,{lv0:lv,fears:['air']});app.clickA('skiptest');return app}
module.exports={playSim,setup};
if(require.main===module){
section('4 · Módulos completos (aprende, practica, simulaciones) en A1, A2 y B1');
for(const lv of [1,2,3])guard('modulos lv'+lv,()=>{const app=setup(lv),T=app.T;ok(T.LV()===lv,'nivel '+lv);
  const mods=lv===1?T.MODS.map(m=>m.id):T.MODS.filter(m=>m.min).map(m=>m.id);
  T.MODS.forEach(m=>{const id=m.id;T.go('mod',id,true);ok(app.text().indexOf(m.n)>=0,'vista módulo '+id);
    app.clickA('go2',id+':learn');ok(app.text().indexOf('Consejos de Miami')>=0,'vista aprender '+id);
    const nPh=T.modPh(m).length;ok(nPh>=5,'frases a nivel en '+id+' ('+nPh+')');
    app.clickA('flashm',id);ok(app.inSession(),'tarjetas '+id);playSession(app,()=>true);if(app.has('done'))app.clickA('done');
    app.clickA('learned',id);ok(T.prog(id).learn,'learn guardado '+id);
    T.go('mod',id,false);app.clickA('prac',id);ok(app.inSession(),'práctica '+id);const r=playSession(app,()=>true);
    ok(T.prog(id).prac>=70,'práctica aprobada '+id+' ('+T.prog(id).prac+'%)');ok(r.n>=8,'práctica con 8+ preguntas '+id+' ('+r.n+')');
    if(app.has('done'))app.clickA('done');
    T.simsOf(id).forEach((s,si)=>{T.go('mod',id,false);app.clickA('sim',s.id);ok(/Empezar la escena/.test(app.text()),'intro sim '+s.id);app.clickA('simgo',s.id);ok(app.inSession(),'arranca sim '+s.id);
      const mode=['best','slip','worst'][(si+lv)%3];const t=playSim(app,mode);ok(/Escena completada/.test(app.text()),'termina sim '+s.id+' ('+mode+')');
      ok(t===s.nd.length,'recorre todos los turnos '+s.id+' '+t+'/'+s.nd.length);const st=T.prog(id).sims[s.id];ok(st>=1&&st<=3,'estrellas guardadas '+s.id+' '+st);
      if(mode==='best')ok(st===3,'camino perfecto = 3 estrellas '+s.id);
      ok(/Para mejorar|Sin fallos/.test(app.text()),'resumen de mejoras')});
    ok(T.modDone(id)&&T.prog(id).done,'módulo '+id+' completado');});
  ok(!!T.S.badges.m5,'insignia de mínimos');ok(!!T.S.badges.sim5,'insignia Actor');ok(T.S.stat.sims>=14,'contador de simulaciones '+T.S.stat.sims);
  console.log('   lv'+lv+': módulos',mods.length,'· XP',T.S.xp,'· insignias',Object.keys(T.S.badges).length)});
section('5 · Reglas de adaptación (punto débil y recomendaciones)');
guard('adaptación',()=>{const app=setup(2),T=app.T;
  T.go('mod','air',true);app.clickA('prac','air');
  /* fallar solo las de escucha: respuesta mala si q.blk==='oral' */
  playSession(app,(i,q)=>q.blk!=='oral');
  const w=app.T.prog('air').sk;console.log('   skills air:',JSON.stringify(w));
  const sug=T.S.sug;ok(!sug||sug.mod==='air','sugerencia coherente');
  if(sug){ok(sug.skill==='oral'||sug.skill==='vocab'||sug.skill==='struct','habilidad válida');ok(/Punto débil|punto más flojo/.test(app.text()+''),'se muestra el punto débil');
    if(app.has('reinf')){app.clickA('reinf','air:'+sug.skill);ok(app.inSession()||/Lección|Gramática|lección/.test(app.text()),'reforzar abre algo ('+sug.skill+')');if(app.inSession()){playSession(app,()=>true);if(app.has('done'))app.clickA('done')}}}
  /* media >=85 con 2 módulos => recomienda extras */
  const T2=setup(2).T;['surv','air'].forEach(id=>{T2.prog(id).prac=95;});ok(T2.S.prog.surv.prac===95,'prog escrito');
  const app3=setup(2);['surv','air'].forEach(id=>{app3.T.prog(id).prac=92});app3.T.showCur();app3.tab('home');
  ok(/Vas sobrada/.test(app3.text()),'recomienda módulos extra con media ≥85 %');
  const app4=setup(2);['surv','air'].forEach(id=>{app4.T.prog(id).prac=60});app4.tab('home');ok(!/Vas sobrada/.test(app4.text()),'no recomienda extras con media baja')});
section('6 · Práctica libre y voz');
guard('practica',()=>{const app=setup(2),T=app.T;app.tab('practice');
  ['fastl','daily','cult'].forEach(a=>{app.tab('practice');app.clickA(a);ok(app.inSession(),'arranca '+a);const r=playSession(app,(i)=>i%3!==0);ok(r.n>=8,a+' preguntas '+r.n);if(app.has('done'))app.clickA('done')});
  ok(Object.keys(T.S.weak).length>0,'las falladas pasan a débiles');app.tab('practice');app.clickA('weak');ok(app.inSession(),'repaso débiles');playSession(app,()=>true);if(app.has('done'))app.clickA('done');
  ok(Object.keys(T.S.srs).length>0,'SRS registra frases');
  /* forzar vencimiento */ Object.keys(T.S.srs).forEach(k=>T.S.srs[k].d=T.dnum()-1);app.tab('practice');ok(app.has('srs'),'aparece repaso espaciado');app.clickA('srs');ok(app.inSession(),'arranca SRS');playSession(app,()=>true);if(app.has('done'))app.clickA('done');
  T.S.set.voice=false;app.tab('practice');app.clickA('fastl');ok(!app.inSession(),'sin sonido no abre escucha');ok(!!app.$('.toast'),'avisa de activar sonido');
  app.clickA('rtest');ok(!app.inSession(),'sin sonido no permite test');
  app.tab('practice');app.clickA('daily');const qs=T.SE?T.SE.qs:[];ok(qs.every(q=>q.blk!=='oral'),'sin sonido no hay preguntas de escucha en el mix');if(app.inSession()){playSession(app,()=>true);if(app.has('done'))app.clickA('done')}})}
if(require.main===module){console.log('\nResumen B:',L.checks(),'comprobaciones,',L.fails.length,'fallos');process.exit(L.fails.length?1:0)}
