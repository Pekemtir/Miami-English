const L=require('./lib.js');const {boot,playSession,ok,section}=L;const {onboard,guard}=require('./run_a.js');
function playSim(app,mode){const T=app.T;let turns=0,slipped={},g=0;
  while(T.SM&&app.inSession()&&g++<80){const SM=T.SM,nd=SM.nodes[SM.cur];const idx=nd.o.map((o,i)=>i);let pick;
    if(mode==='best')pick=idx.find(i=>nd.o[i][2]===2);
    else if(mode==='slip'){const z=idx.find(i=>nd.o[i][2]===0&&!SM.used[SM.cur+':'+i]);pick=(!slipped[SM.cur]&&z!==undefined)?z:idx.find(i=>nd.o[i][2]===2);slipped[SM.cur]=1}
    else{const o1=idx.find(i=>nd.o[i][2]===1);pick=(o1!==undefined)?o1:idx.find(i=>nd.o[i][2]===2)}
    app.clickA('simpick',String(pick));const nx=app.$('#nx');if(!nx)throw new Error('sin hoja de feedback');app.click(nx);if(nd.o[pick][2]>0)turns++}
  return turns}
function setup(lv){const app=boot({});onboard(app,{lv0:lv,fears:['air']});app.clickA('skiptest');return app}
module.exports={playSim,setup};
if(require.main===module){
section('4 · Módulos completos (aprende, practica, simulaciones) en A1, A2, B1 y B2');
for(const lv of [1,2,3,4])guard('modulos lv'+lv,()=>{const app=setup(lv),T=app.T;ok(T.LV()===lv,'nivel '+lv);
  const mods=lv===1?T.MODS.map(m=>m.id):T.MODS.filter(m=>m.min).map(m=>m.id);
  T.MODS.forEach(m=>{const id=m.id;T.go('mod',id,true);ok(app.text().indexOf(m.n)>=0,'vista módulo '+id);
    app.clickA('go2',id+':learn');ok(app.text().indexOf('Consejos de Miami')>=0,'vista aprender '+id);
    const nPh=T.modPh(m).length;ok(nPh>=5,'frases a nivel en '+id+' ('+nPh+')');
    app.clickA('flashm',id);ok(app.inSession(),'tarjetas '+id);playSession(app,()=>true);if(app.has('done'))app.clickA('done');
    app.clickA('learned',id);ok(T.prog(id).learn,'learn guardado '+id);
    T.go('mod',id,false);app.clickA('prac',id);ok(app.inSession(),'práctica '+id);const r=playSession(app,()=>true);
    ok(T.prog(id).prac>=70,'práctica aprobada '+id+' ('+T.prog(id).prac+'%)');ok(r.n>=8,'práctica con 8+ preguntas '+id+' ('+r.n+')');
    if(app.has('done'))app.clickA('done');
    T.simsOf(id).forEach((s,si)=>{T.go('mod',id,false);app.clickA('sim',s.id);ok(/Empezar la escena/.test(app.text()),'intro sim '+s.id);app.clickA('simgo',s.id);ok(app.inSession(),'arranca sim '+s.id);
      const mode=['best','slip','worst'][(si+lv)%3];const t=playSim(app,mode);ok(/Escena completada/.test(app.text()),'termina sim '+s.id+' ('+mode+')');
      ok(t===s.nd.length,'recorre todos los turnos '+s.id+' '+t+'/'+s.nd.length);const st=T.prog(id).sims[s.id];ok(st>=1&&st<=3,'estrellas guardadas '+s.id+' '+st);
      if(mode==='best')ok(st===3,'camino perfecto = 3 estrellas '+s.id);
      ok(/Para mejorar|Sin fallos/.test(app.text()),'resumen de mejoras')});
    ok(T.modDone(id)&&T.prog(id).done,'módulo '+id+' completado');});
  ok(!!T.S.badges.m5,'insignia de mínimos');ok(!!T.S.badges.sim5,'insignia Actor');ok(T.S.stat.sims>=14,'contador de simulaciones '+T.S.stat.sims);
  console.log('   lv'+lv+': módulos',mods.length,'· XP',T.S.xp,'· insignias',Object.keys(T.S.badges).length)});
section('5 · Reglas de adaptación (punto débil y recomendaciones)');
guard('adaptación',()=>{const app=setup(2),T=app.T;
  T.go('mod','air',true);app.clickA('prac','air');
  /* fallar solo las de escucha: respuesta mala si q.blk==='oral' */
  playSession(app,(i,q)=>q.blk!=='oral');
  const w=app.T.prog('air').sk;console.log('   skills air:',JSON.stringify(w));
  const sug=T.S.sug;ok(!sug||sug.mod==='air','sugerencia coherente');
  if(sug){ok(sug.skill==='oral'||sug.skill==='vocab'||sug.skill==='struct','habilidad válida');ok(/Punto débil|punto más flojo/.test(app.text()+''),'se muestra el punto débil');
    if(app.has('reinf')){app.clickA('reinf','air:'+sug.skill);ok(app.inSession()||/Lección|Gramática|lección/.test(app.text()),'reforzar abre algo ('+sug.skill+')');if(app.inSession()){playSession(app,()=>true);if(app.has('done'))app.clickA('done')}}}
  /* media >=85 con 2 módulos => recomienda extras */
  const T2=setup(2).T;['surv','air'].forEach(id=>{T2.prog(id).prac=95;});ok(T2.S.prog.surv.prac===95,'prog escrito');
  const app3=setup(2);['surv','air'].forEach(id=>{app3.T.prog(id).prac=92});app3.T.showCur();app3.tab('home');
  ok(/Vas sobrada/.test(app3.text()),'recomienda módulos extra con media ≥85 %');
  const app4=setup(2);['surv','air'].forEach(id=>{app4.T.prog(id).prac=60});app4.tab('home');ok(!/Vas sobrada/.test(app4.text()),'no recomienda extras con media baja')});
section('6 · Práctica libre y voz');
guard('practica',()=>{const app=setup(2),T=app.T;app.tab('practice');
  ['fastl','daily','cult'].forEach(a=>{app.tab('practice');app.clickA(a);ok(app.inSession(),'arranca '+a);const r=playSession(app,(i)=>i%3!==0);ok(r.n>=8,a+' preguntas '+r.n);if(app.has('done'))app.clickA('done')});
  ok(Object.keys(T.S.weak).length>0,'las falladas pasan a débiles');app.tab('practice');app.clickA('weak');ok(app.inSession(),'repaso débiles');playSession(app,()=>true);if(app.has('done'))app.clickA('done');
  ok(Object.keys(T.S.srs).length>0,'SRS registra frases');
  /* forzar vencimiento */ Object.keys(T.S.srs).forEach(k=>T.S.srs[k].d=T.dnum()-1);app.tab('practice');ok(app.has('srs'),'aparece repaso espaciado');app.clickA('srs');ok(app.inSession(),'arranca SRS');playSession(app,()=>true);if(app.has('done'))app.clickA('done');
  T.S.set.voice=false;app.tab('practice');app.clickA('fastl');ok(!app.inSession(),'sin sonido no abre escucha');ok(!!app.$('.toast'),'avisa de activar sonido');
  app.clickA('rtest');ok(app.inSession(),'sin sonido el test arranca (sin escucha)');const seenL=[];const r1=playSession(app,(i,q)=>{if(q&&q.blk==='l')seenL.push(1);return true});ok(seenL.length===0,'sin sonido el test no tiene preguntas de escucha');ok(r1.n>=20,'test sin sonido: '+r1.n+' preguntas');ok(T.S.test&&T.S.test.cat.l.tot===0&&T.S.test.lv>=1,'nivel calculado sin la habilidad oral: lv '+(T.S.test&&T.S.test.lv));
  app.tab('practice');app.clickA('ftest');ok(app.inSession(),'test final sin sonido arranca');const sL=[];playSession(app,(i,q)=>{if(q&&q.blk==='l')sL.push(1);return true});ok(sL.length===0,'test final sin escucha');
  app.tab('practice');app.clickA('daily');const qs=T.SE?T.SE.qs:[];ok(qs.every(q=>q.blk!=='oral'),'sin sonido no hay preguntas de escucha en el mix');if(app.inSession()){playSession(app,()=>true);if(app.has('done'))app.clickA('done')}})}
if(require.main===module){section('6b · Hablar (micrófono, autoevaluación), plan y aviso iPhone');
guard('hablar',()=>{const app=setup(2),T=app.T;const S=T.S;
  ok(T.speakScore('Could I have a coffee, please?','could i have a coffee please')===1,'puntuación ignora mayúsculas y puntuación');
  ok(T.speakScore("I'd like a table for two.",'i d like a table for two')>=.8,'tolera el apóstrofo');
  ok(T.speakScore('Where is the bathroom?','banana banana banana')===0,'sin coincidencias = 0');
  {const P=Object.values(T.PH).find(p=>p.en==='One moment, please.');const q={ans:P.en,alt:T.altOf(P.en)};
   ok(T.speakOK(q,'wait a moment please').ok&&!T.speakOK(q,'wait a moment please').main,'variante «wait a moment please» vale y no es la principal');
   ok(T.speakOK(q,'one moment please').main,'frase principal detectada');
   ok(!T.speakOK(q,'I want pizza').ok,'frase ajena no vale');
   ok(/informales|orden/.test(T.speakNote(q,'hold on')),'nota de registro de One moment');}
  ok(T.speakOK({ans:'Could you take me to this address?',alt:T.altOf('Could you take me to this address?')},'can you take me to this address').main===false,'«can you…» es variante, no la principal (aunque puntúe ≥75 % en la principal)');
  ok(T.speakOK({ans:'Go straight ahead.',alt:T.altOf('Go straight ahead.')},'go straight').ok,'variante corta «go straight»');
  ok(T.speakOK({ans:'Call nine one one, please.',alt:T.altOf('Call nine one one, please.')},'call 911 please').ok,'911 como cifras');
  ok(!T.speakOK({ans:'Excuse me.',alt:T.altOf('Excuse me.')},'excuse').ok,'≤2 palabras exigen todas');
  {const miss=Object.keys(T.ALT_RAW).filter(k=>!Object.values(T.PH).some(p=>T.wnorm(p.en).join(' ')===T.wnorm(k).join(' ')));ok(!miss.length,'todas las claves de ALT_RAW existen como frase'+(miss.length?': '+miss.join(' | '):''));
   const miss2=Object.keys(T.NOTE_RAW).filter(k=>!Object.values(T.PH).some(p=>T.wnorm(p.en).join(' ')===T.wnorm(k).join(' ')));ok(!miss2.length,'todas las claves de NOTE_RAW existen'+(miss2.length?': '+miss2.join(' | '):''));
   const noalt=Object.values(T.PH).filter(p=>!T.altOf(p.en).length).length;console.log('frases sin variantes:',noalt,'de',Object.keys(T.PH).length);}
  /* sin reconocimiento de voz: autoevaluación */
  app.tab('practice');app.clickA('speakp');ok(app.inSession(),'arranca Hablar');ok(!app.has('mic'),'sin micro no hay botón de micrófono');ok(/Tu navegador no reconoce voz/.test(app.text()),'explica la autoevaluación');
  ok(!!app.$('[data-a="sayno"]'),'se puede saltar');app.clickA('showen');ok(!!app.$('[data-a="sayok"]'),'tras ver la frase aparece valorarse');
  const q0=T.SE.cur;ok(q0.k==='speak'&&q0.blk==='speak','pregunta de tipo hablar');app.clickA('sayok');ok(/¡|Sí|Exacto|Perfecto/.test(app.$('#sheet').textContent),'acierto al valorarse');app.clickA('next');
  app.clickA('showen');app.clickA('sayno');ok(/Respuesta correcta/.test(app.$('#sheet').textContent),'fallo muestra la frase');app.clickA('next');
  playSession(app,()=>true);if(app.has('done'))app.clickA('done');ok(!app.inSession(),'termina la sesión');
  /* con reconocimiento de voz simulado */
  let say='';app.env.ctx.webkitSpeechRecognition=class{start(){const t=say;if(t==='ERR'){this.onerror({error:'not-allowed'});return}if(t==='SILENCE'){this.onend();return}this.onresult({results:[[{transcript:t},{transcript:'x y z'}]]});this.onend()}};
  app.tab('practice');app.clickA('speakp');ok(app.has('mic'),'con micro aparece el botón');
  let q=T.SE.cur;say='ERR';app.clickA('mic');ok(!T.SE.locked&&/Permite el micrófono/.test([].slice.call(app.$$('.toast')).map(x=>x.textContent).join('|')),'permiso denegado: aviso y sigue la pregunta');
  say='SILENCE';app.clickA('mic');ok(!T.SE.locked&&/No te he oído/.test(app.text()),'silencio: pide repetir');
  say='banana banana';app.clickA('mic');ok(!T.SE.locked&&/Te he oído/.test(app.text()),'frase errónea: muestra lo oído y deja repetir');
  say=q.ans.toLowerCase().replace(/[.,?!]/g,'');app.clickA('mic');ok(T.SE.locked&&/Te he entendido/.test(app.$('#sheet').textContent),'frase correcta: acierta');app.clickA('next');
  q=T.SE.cur;const w=q.ans.split(' ');if(w.length>=4){say=w.slice(0,w.length-1).join(' ');app.clickA('mic');ok(T.SE.locked,'un 75 % de las palabras vale')}else{say=q.ans;app.clickA('mic')}app.clickA('next');
  playSession(app,()=>true);if(app.has('done'))app.clickA('done');
  /* plan: pasos Habla */
  const lv=T.S.test.lv;T.buildPlan();const talk=T.S.plan.items.filter(i=>i.t==='talk');ok(talk.length===T.MINS.length,'un paso Habla por módulo imprescindible ('+talk.length+')');
  app.tab('plan');const idx=T.S.plan.items.indexOf(talk[0]);app.clickA('stepgo',idx);ok(app.inSession(),'el paso Habla abre sesión');ok(!T.itemDone(talk[0]),'aún no hecho');
  playSession(app,()=>true);if(app.has('done'))app.clickA('done');ok(T.itemDone(talk[0]),'completar la sesión marca el paso hecho');
  /* aviso iPhone */
  app.env.ctx.navigator.userAgent='Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)';app.env.ctx.navigator.standalone=false;app.tab('home');ok(/Instálala/.test(app.text()),'iPhone en Safari: aviso de instalar');
  app.clickA('noinst');ok(!/Instálala/.test(app.text())&&T.S.set.noinst===1,'se puede ocultar');
  app.env.ctx.navigator.userAgent='Mozilla/5.0 (Linux; Android 14)';T.S.set.noinst=0;app.tab('home');ok(!/Instálala/.test(app.text()),'Android: sin aviso');
  app.env.ctx.navigator.userAgent='Mozilla/5.0 (iPhone)';app.env.ctx.navigator.standalone=true;app.tab('home');ok(!/Instálala/.test(app.text()),'iPhone ya instalada: sin aviso')})}
if(require.main===module){console.log('\nResumen B:',L.checks(),'comprobaciones,',L.fails.length,'fallos');process.exit(L.fails.length?1:0)}
