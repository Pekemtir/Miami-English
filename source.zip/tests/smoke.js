const L=require('./lib.js');const app=L.boot({});
console.log('arranque ok; texto inicio:',app.text().slice(0,80));
L.ok(/Miami English/.test(app.text()),'home muestra título');L.ok(app.has('onb'),'botón Empezar');
console.log(L.fails.length?'FALLOS':'sin fallos');
