const L=require('./lib.js');const {boot,playSession,ok,section}=L;
const guard=(n,f)=>{try{f()}catch(e){console.log('  ✗ EXCEPCIÓN en',n,':',e.message);L.fails.push(n+': '+e.message)}};
function onboard(app,o){o=o||{};app.clickA('onb');
  app.type('#onn',o.name===undefined?'Lucía':o.name);
  app.clickA('onset','goal:'+(o.goal||'tour'));(o.fears||['rest','emer']).forEach(f=>app.clickA('onfear',f));
  app.clickA('onset','weeks:'+(o.weeks||6));app.clickA('onset','mins:'+(o.mins||15));app.clickA('onset','days:'+(o.days||5));
  ['speak','listen','read'].forEach((k,i)=>app.clickA('onself',k+':'+((o.self||[2,2,3])[i])));app.clickA('onset','lv0:'+(o.lv0||0));
  app.clickA('onbsave')}
module.exports={onboard,guard};
if(require.main===module){
section('1 · Onboarding');
guard('onboarding',()=>{const app=boot({});
  app.clickA('onb');ok(/Cuéntame sobre ti/.test(app.text()),'abre onboarding');
  app.clickA('onbsave');ok(!app.T.S.prof,'sin nombre no guarda perfil');ok(!!app.$('.toast'),'avisa de que falta el nombre');
  app.type('#onn','Lucía');app.clickA('onfear','air');app.clickA('onfear','air');app.clickA('onfear','emer');
  app.clickA('onset','weeks:4');ok(app.T.S.prof===null||true,'');app.clickA('onset','mins:20');app.clickA('onset','days:3');
  ok(app.$('#onn').value==='Lucía','el nombre sobrevive al re-render');
  app.clickA('onbsave');const P=app.T.S.prof;ok(P&&P.name==='Lucía'&&P.weeks===4&&P.mins===20&&P.days===3&&P.fears.length===1&&P.fears[0]==='emer','perfil guardado con las opciones: '+JSON.stringify(P));
  ok(/Test de nivel/.test(app.text()),'pasa a la pantalla del test');
  ok(app.T.LV()>=1,'nivel provisional');
  /* fecha de viaje */
  app.tab('me');app.clickA('onb');app.$('#ond').value=new Date(Date.now()+20*864e5).toISOString().slice(0,10);L.fire(app.env,app.$('#ond'),'change');app.clickA('onbsave');
  ok(app.T.S.prof.weeks===3,'la fecha de viaje en 20 días da 3 semanas (da '+app.T.S.prof.weeks+')')});
section('2 · Test de nivel (adaptativo)');
let app0=null;for(const [name,pol,expect] of [['todo bien',()=>true,4],['nivel B1',(i,q)=>!(q&&q._tb!=null&&app0.T.TB[q._tb].lv===4),3],['todo mal',()=>false,1],['mitad',(i)=>i%2===0,null]]){guard('test '+name,()=>{const app=boot({});app0=app;onboard(app);
  app.clickA('stest');ok(app.inSession(),'arranca el test ('+name+')');let sawAns=false;
  const r=playSession(app,(i,q)=>{return pol(i,q)});
  ok(r.n>=20&&r.n<=30,'hace entre 20 y 30 preguntas ('+r.n+')');
  const t=app.T.S.test;ok(t&&t.lv>=1&&t.lv<=4,'guarda nivel ('+name+'): '+(t&&t.lv));
  if(expect)ok(t.lv===expect,name+' → nivel esperado '+expect+', obtenido '+t.lv);
  ok(/Tu nivel/.test(app.text()),'muestra resultado');ok(app.has('mkplan'),'ofrece generar plan');
  const cats=Object.keys(t.cat);ok(cats.length===4,'4 categorías');
  console.log('   ',name,'→ nivel',t.lv,'· aciertos',t.score+'%','· preguntas',r.n)})}
guard('test sin mostrar respuestas',()=>{const app=boot({});onboard(app);app.clickA('stest');
  const q=app.T.SE.cur;const wrong=app.$$('.opt').find(b=>b.dataset.v!==q.ans);app.click(wrong);const sh=app.$('#sheet').textContent;
  ok(!/Respuesta correcta/.test(sh),'el test no revela la respuesta');ok(app.has('next'),'botón continuar')});
guard('saltar test',()=>{const app=boot({});onboard(app,{lv0:2});app.clickA('skiptest');ok(app.T.S.test&&app.T.S.test.skipped&&app.T.S.test.lv===2,'salta con nivel 2');ok(!!app.T.S.plan,'genera plan al saltar')});
section('3 · Generación de plan (reglas)');
guard('plan',()=>{const app=boot({});const T=app.T;let n=0;
  for(const lv of [1,2,3,4])for(const weeks of [2,6,12])for(const [mins,days] of [[10,3],[15,5],[45,7]])for(const fears of [[],['emer','air'],['surv','money','soc']])for(const weak of [null,'l','g']){
    T.S.prof={name:'T',goal:['tour','work','study','def'][n%4],fears:fears,weeks:weeks,mins:mins,days:days,self:{},lv0:lv};
    T.S.test={lv:lv,cat:weak?{[weak]:{ok:1,tot:5},v:{ok:5,tot:5},g:{ok:5,tot:5},r:{ok:5,tot:5},l:{ok:5,tot:5}}:{},score:50,date:'x',used:[]};
    if(weak){T.S.test.cat[weak]={ok:1,tot:5}}
    const P=T.buildPlan();n++;const tag='lv'+lv+' w'+weeks+' '+mins+'x'+days+' f'+fears.join('+')+' '+weak;
    T.MINS.forEach(id=>{ok(P.items.some(i=>i.t==='talk'&&i.mod===id),tag+': talk '+id);ok(P.items.some(i=>i.t==='learn'&&i.mod===id),tag+': learn '+id);ok(P.items.some(i=>i.t==='prac'&&i.mod===id),tag+': prac '+id);T.simsOf(id).forEach(s=>ok(P.items.some(i=>i.t==='sim'&&i.sim===s.id),tag+': sim '+s.id))});
    ok(P.items[P.items.length-1].t==='final','plan acaba en test final '+tag);
    const keys=P.items.map(i=>[i.t,i.mod,i.sim,i.les].join('|'));ok(new Set(keys).size===keys.length,'sin duplicados '+tag);
    let prev=0,mono=true;P.items.forEach(i=>{if(i.w<prev)mono=false;prev=i.w});ok(mono,'semanas no decrecen '+tag);
    ok(P.items[0].mod==='surv','empieza por Supervivencia '+tag);
    ok(P.items.every(i=>!T.itemDone(i)),'todo pendiente al inicio '+tag);
    ok((lv===1)===P.items.filter(i=>i.t==='gr').length>=6||lv!==1||P.items.filter(i=>i.t==='gr').length===6,'GR completo en A1 '+tag);
    ok(lv>=2||!P.items.some(i=>i.t==='b1'),'B1 solo desde A2 '+tag);
    if(lv===3&&weeks>=6&&mins>=15)ok(P.items.filter(i=>i.t==='b1').length>=10,'B1 abundante en B1 '+tag+' ('+P.items.filter(i=>i.t==='b1').length+')');
    ok(lv>=4||!P.items.some(i=>i.les&&i.les[0]==='c'),'B2 solo en nivel B2 '+tag);
    if(lv===4&&weeks>=6&&mins>=15)ok(P.items.filter(i=>i.t==='b1'&&i.les[0]==='c').length>=10,'B2 abundante en B2 '+tag+' ('+P.items.filter(i=>i.t==='b1'&&i.les[0]==='c').length+')');
    ok(weak==='l'===P.items.some(i=>i.t==='drill'),'drills solo con oral débil '+tag);
    const order=P.items.filter(i=>i.t==='learn'&&T.MINS.includes(i.mod)).map(i=>i.mod);
    const fm=fears.filter(f=>T.MINS.includes(f)&&f!=='surv');if(fm.length)ok(order.indexOf(fm[0])<=1+fm.length,'miedos primero '+tag+' '+order.join(','));
    ok(P.tight===(P.used>P.budget),'flag tight coherente '+tag);}
  console.log('   combinaciones de plan comprobadas:',n)});
if(require.main===module){console.log('\nResumen A:',L.checks(),'comprobaciones,',L.fails.length,'fallos');process.exit(L.fails.length?1:0)}
}
