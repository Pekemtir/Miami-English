const L=require('./lib.js');const {boot,playSession,ok,section}=L;const {onboard,guard}=require('./run_a.js');const {setup}=require('./run_b.js');
const uniq=a=>new Set(a.map(x=>String(x).toLowerCase().replace(/[^a-z0-9áéíóúñ ]/g,''))).size===a.length;
section('7 · Generadores de preguntas (muchas iteraciones)');
guard('fuzz',()=>{const app=setup(3),T=app.T;let n=0,bad=0;
  for(const lv of [1,2,3,4]){T.S.test.lv=lv;for(let it=0;it<60;it++){T.mixQs(T.allPh(),20).forEach(q=>{n++;const key=q.key&&q.key.slice(2),ph=key&&T.PH[key];let m=null;
    if(!q.kind||!q.blk){m='sin kind/blk'}
    else if(q.k==='choice'){const all=[q.ans].concat(q.opts);if(q.opts.length<2)m='pocas opciones';else if(!uniq(all))m='opciones repetidas: '+all.join('|');else if(!q.ans)m='sin respuesta'}
    else if(q.k==='type'){if(!q.alts.includes(q.ans))m='alts sin ans';else if(q.p.indexOf('_____')<0)m='sin hueco';else if(ph&&ph.en.toLowerCase().indexOf(q.ans.toLowerCase())<0)m='respuesta no está en la frase: '+q.ans}
    else if(q.k==='build'){if(q.tok.join(' ')!==q.ans)m='tokens != respuesta';else if(q.tok.length<3||q.tok.length>9)m='longitud';else if(q.extra.some(x=>q.tok.map(t=>t.toLowerCase()).includes(x)))m='extra repetido'}
    else m='tipo '+q.k;
    if(q.blk==='oral'&&!q.hide)m='oral sin ocultar';
    if(!m&&ph&&q.k==='choice'){const allowed=new Set();T.allPh(lv).forEach(x=>{allowed.add(x.en);allowed.add(x.es)});const bad2=[q.ans].concat(q.opts).filter(o=>!allowed.has(o)&&o!==q.p);if(bad2.length)m='texto de nivel superior a lv'+lv+' en opciones: '+bad2.join(' | ')}
    if(!m&&q.k==='build'){const allowed=new Set();T.allPh(lv).forEach(x=>x.en.split(' ').forEach(w=>allowed.add(w)));const b3=q.extra.filter(w=>!allowed.has(w));if(b3.length)m='palabra extra de nivel superior: '+b3.join(',')}
    if(m){bad++;if(bad<6)console.log('   ✗',m,JSON.stringify(q).slice(0,150))}})}}
  ok(bad===0,'generadores: '+bad+' preguntas defectuosas de '+n);console.log('   preguntas generadas y validadas:',n)});
section('8 · Lecciones B1, B2 y refuerzo (46) · vista, práctica con respuestas válidas y tolerancia');
guard('lecciones',()=>{const app=setup(3),T=app.T;[].concat(T.B1,T.B2,T.GR).forEach(l=>{T.go('lesson',l.id,true);ok(app.text().indexOf(l.n)>=0&&/Practicar/.test(app.text()),'vista '+l.id);
    const qs=T.lessonQs(l);ok(qs.length===l.q.length,'preguntas '+l.id);
    qs.forEach(q=>{if(q.k==='type'){q.alts.forEach(a=>{ok(T.checkType(q,a).ok,'acepta «'+a+'» en '+l.id);ok(T.checkType(q,a.toUpperCase()+' ').ok,'insensible a mayúsculas '+a);const na=a.replace(/'/g,'');ok(T.checkType(q,na).ok,'tolera sin apóstrofo «'+na+'»')});ok(!T.checkType(q,'zzz').ok,'rechaza basura')}});
    app.clickA('lpractice',l.id);ok(app.inSession(),'sesión '+l.id);playSession(app,()=>true);ok(T.S.les[l.id]&&T.S.les[l.id].best===100,'100 % guardado '+l.id+' '+JSON.stringify(T.S.les[l.id]));if(app.has('done'))app.clickA('done')});
  app.tab('practice');app.clickA('go','b1list');ok(app.$$('[data-a="lesson"]').length===18,'lista B1 con 18');app.clickA('lesson','b01');
  app.$('#back')&&L.fire(app.env,app.$('#back'),'click');ok(/Curso B1/.test(app.text()),'botón atrás vuelve a la lista');
  app.tab('practice');app.clickA('go','b2list');ok(app.$$('[data-a="lesson"]').length===22,'lista B2 con 22');app.clickA('lesson','c01');
  app.$('#back')&&L.fire(app.env,app.$('#back'),'click');ok(/Curso B2/.test(app.text()),'atrás vuelve a la lista B2');
  app.tab('practice');app.clickA('go','grs');ok(app.$$('[data-a="lesson"]').length===6,'lista refuerzo con 6');
  /* errores: fallar y ver que se repite la pregunta */
  app.tab('practice');app.clickA('go','b1list');const l=T.B1[0];app.clickA('lesson',l.id);app.clickA('lpractice',l.id);const total0=T.SE.qs.length;playSession(app,(i)=>i!==0);ok(T.S.les[l.id].best>=80,'un fallo no hunde la nota');});
section('9 · Plan en pantalla: cada paso abre lo que toca');
guard('pasos',()=>{for(const lv of [1,3,4]){const app=setup(lv),T=app.T;app.tab('plan');const items=T.S.plan.items;ok(app.$$('[data-a="stepgo"]').length===items.length,'filas del plan = pasos ('+items.length+')');
  items.forEach((it,i)=>{app.tab('plan');app.clickA('stepgo',String(i));const kind=it.t;const opened=app.inSession()||T.CUR.v!=='plan';ok(opened,'paso '+kind+' abre algo (lv'+lv+', #'+i+')');
    if(app.inSession()){app.clickA('quit')}})}
  const app=setup(2);app.tab('home');ok(/Hoy toca/.test(app.text()),'home muestra el siguiente paso');app.clickA('stepgo','0');ok(T0(app)==='learn','el primer paso es aprender Supervivencia')});
function T0(app){return app.T.CUR.v}
section('10 · Test final');
guard('final',()=>{const app=setup(2),T=app.T;T.MINS.forEach(id=>{const p=T.prog(id);p.learn=true;p.prac=90;T.simsOf(id).forEach(s=>p.sims[s.id]=3);p.done=true});
  T.showCur();app.tab('plan');ok(app.has('ftest'),'ofrece test final al acabar mínimos');app.clickA('ftest');ok(app.inSession(),'arranca');const r=playSession(app,()=>true);
  ok(r.n===20,'20 preguntas ('+r.n+')');ok(!!T.S.fin&&T.S.fin.score===100,'guarda resultado');ok(/Test final/.test(app.text())&&/Nivel inicial/.test(app.text()),'compara con el inicial');ok(!!T.S.badges.ft,'insignia')});
section('11 · Frases, tarjeta, ajustes, copia y persistencia');
guard('frases',()=>{const app=setup(2),T=app.T;app.tab('phrases');ok(/Frases/.test(app.text()),'pestaña frases');
  app.type('#pq','passport');ok(/passport/i.test(app.$('#pres').textContent),'búsqueda por inglés');app.type('#pq','baño');ok(/restroom/i.test(app.$('#pres').textContent),'búsqueda por castellano');app.type('#pq','');
  T.MODS.forEach(m=>{app.clickA('pfm',m.id);ok(app.$$('#pres .hit').length===Math.min(80,m.ph.length),'filtro '+m.id)});
  app.clickA('pfm','all');app.clickA('go','card');ok(app.$$('.hit').length===30,'tarjeta con 30 frases');ok(new Set(T.key30().map(p=>p.id)).size===30,'30 frases distintas');
  app.clickA('copyc');ok(/Excuse me/.test(app.env.ctx.__clip||''),'copiar tarjeta');app.clickA('printc')});
guard('ajustes',()=>{const app=setup(2),T=app.T;app.tab('me');
  app.clickA('svoice');ok(T.S.set.voice===false,'silencio');app.clickA('svoice');ok(T.S.set.voice===true,'sonido');
  app.clickA('srate','1.1');ok(T.S.set.rate===1.1,'velocidad');app.clickA('sfast');ok(T.S.set.fast===true,'ritmo real');
  app.clickA('stheme','light');ok(app.env.doc.documentElement.attrs['data-theme']==='light','tema claro');app.clickA('stheme','auto');
  app.clickA('sgoal','50');ok(T.S.goal===50,'objetivo');
  const v=app.$('#vsel');v.value='Test US';L.fire(app.env,v,'change');ok(T.S.set.voiceName==='Test US','voz elegida');
  app.clickA('bkcopy');const js=app.env.ctx.__clip;ok(js&&JSON.parse(js).v===1,'copia de seguridad JSON');
  app.clickA('bkshow');ok(!!app.$('#bkt'),'caja de importar');const snap=JSON.parse(js);snap.xp=4321;app.$('#bkt').value=JSON.stringify(snap);app.clickA('bkimp');ok(T.S.xp===4321,'importar restaura ('+T.S.xp+')');
  app.$('#bkt')&&0;app.tab('me');app.clickA('bkshow');app.$('#bkt').value='no es json';app.clickA('bkimp');ok(!!app.$('.toast'),'rechaza copia inválida');
  app.clickA('reset');ok(T.S.prof===null&&T.S.xp===0,'borrar todo');ok(/Empezar/.test(app.text()),'vuelve a inicio')});
guard('persistencia',()=>{const store={};const a=boot(store);onboard(a,{name:'Lucía',lv0:2});a.clickA('skiptest');a.T.go('mod','surv',true);a.clickA('prac','surv');playSession(a,()=>true);const xp=a.T.S.xp;
  const b=boot(store);ok(b.T.S.xp===xp&&xp>0,'XP persiste');b.tab('home');ok(/Hola, Lucía/.test(b.text()),'saludo tras recargar');ok(!!b.T.S.plan&&b.T.prog('surv').prac>=70,'plan y progreso persisten');
  const bad=boot({'miami-english-v1':'{rota'});ok(/Miami English/.test(bad.text()),'arranca con datos corruptos');
  const old=boot({'miami-english-v1':JSON.stringify({v:1,xp:5})});old.tab('plan');old.tab('practice');old.tab('me');ok(old.T.S.xp===5&&!!old.T.S.les,'arranca con guardado antiguo/incompleto');
  const x=boot({});x.clickA('onb');x.type('#onn','<img src=x onerror=1>');x.clickA('onbsave');x.clickA('skiptest');x.tab('home');ok(!x.$('#app img'),'el nombre se escapa (sin HTML inyectado)');ok(/<img/.test(x.text()),'se muestra literal')});
console.log('\nResumen C:',L.checks(),'comprobaciones,',L.fails.length,'fallos');process.exit(L.fails.length?1:0);
