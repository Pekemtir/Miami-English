/* Audita los datos: estructura, duplicados, respuestas presentes, saltos de simulación válidos */
const fs=require('fs'),vm=require('vm'),path=require('path');
const src=path.join(__dirname,'..','src');
const files=fs.readdirSync(src).filter(f=>/^0[1-4].*\.js$/.test(f)).sort();
let code=files.map(f=>fs.readFileSync(path.join(src,f),'utf8')).join('\n');
code+='\n;this.__out={MODS:typeof MODS!=="undefined"?MODS:null,PH:typeof PH!=="undefined"?PH:null,SIMS:typeof SIMS!=="undefined"?SIMS:null,B1:typeof B1!=="undefined"?B1:null,TB:typeof TB!=="undefined"?TB:null,GR:typeof GR!=="undefined"?GR:null,CULT:typeof CULT!=="undefined"?CULT:null};';
const ctx={};vm.createContext(ctx);vm.runInContext(code,ctx);
const {MODS,PH,SIMS,B1,TB,GR,CULT}=ctx.__out;
const bad=[];const note=m=>bad.push(m);
let n=0;
if(MODS){MODS.forEach(m=>{const seen=new Set();m.ph.forEach(p=>{n++;if(!p.en||!p.es)note('frase vacía '+p.id);if(![1,2,3].includes(p.lv))note('nivel '+p.id);const k=p.en.toLowerCase();if(seen.has(k))note('duplicada '+m.id+': '+p.en);seen.add(k)});
  [1,2,3].forEach(l=>{if(m.ph.filter(p=>p.lv===l).length<3)note('pocas frases lv'+l+' en '+m.id)})})}
if(SIMS){SIMS.forEach(s=>{const ids=s.nd.map(x=>x[0]);if(new Set(ids).size!==ids.length)note('ids repetidos '+s.id);
  s.nd.forEach(nd=>{const o=nd[3];if(!o||o.length<3)note(s.id+'/'+nd[0]+' opciones');if(!o.some(x=>x[2]===2))note(s.id+'/'+nd[0]+' sin opción 2');if(!o.some(x=>x[2]===0))note(s.id+'/'+nd[0]+' sin opción 0');
    o.forEach(x=>{if(!x[0]||!x[1]||x[3]==null)note(s.id+'/'+nd[0]+' opción incompleta');if(x[5]&&x[5]!=='end'&&!ids.includes(x[5]))note(s.id+'/'+nd[0]+' salto inválido '+x[5]);
      if(x[2]===0&&x[5])note(s.id+'/'+nd[0]+' opción 0 no debe saltar')})});
  if(!MODS.find(m=>m.id===s.mod))note('sim sin módulo '+s.id)})}
if(B1){B1.forEach(l=>{if(l.q.length<8)note(l.id+' pocas preguntas');if(!l.st||!l.st.length)note(l.id+' sin teoría');
  l.q.forEach((q,i)=>{const t=q[0];
    if(t==='c'){const all=[q[2]].concat(q[3]);if(new Set(all.map(x=>x.toLowerCase())).size!==all.length)note(l.id+' q'+i+' opciones duplicadas');if(q[3].length<2)note(l.id+' q'+i+' pocos distractores')}
    else if(t==='t'){if(!q[2])note(l.id+' q'+i+' sin respuesta')}
    else if(t==='b'){if(q[2].split(' ').length<3)note(l.id+' q'+i+' build corto')}
    else note(l.id+' q'+i+' tipo '+t)})})}
if(TB){TB.forEach((q,i)=>{const all=[q.a].concat(q.w);if(new Set(all.map(x=>String(x).toLowerCase())).size!==all.length)note('TB '+i+' duplicadas');if(![1,2,3].includes(q.lv))note('TB '+i+' nivel');if(!['v','g','r','l'].includes(q.k))note('TB '+i+' categoría')});
  [1,2,3].forEach(l=>['v','g','r','l'].forEach(k=>{const c=TB.filter(q=>q.lv===l&&q.k===k).length;if(c<3)note('TB pocos lv'+l+' '+k+': '+c)}))}
console.log({frases:n,sims:SIMS&&SIMS.length,b1:B1&&B1.length,preguntasB1:B1&&B1.reduce((a,l)=>a+l.q.length,0),test:TB&&TB.length,problemas:bad.length});
bad.forEach(b=>console.log(' -',b));process.exit(bad.length?1:0);
