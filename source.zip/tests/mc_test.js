// Monte Carlo: precisión del test de nivel con alumnos simulados (probabilidad de acierto por nivel de pregunta, incluye azar 25 %)
const {boot,playSession}=require('./lib.js');const {onboard}=require('./run_a.js');
const P={A1:[.85,.45,.30,.25],A2:[.95,.80,.45,.30],B1:[.97,.90,.75,.40],B2:[.98,.95,.88,.75]};
const N=+process.argv[2]||60;const out={};
for(const [name,p] of Object.entries(P)){const c={1:0,2:0,3:0,4:0};
  for(let k=0;k<N;k++){const app=boot({});onboard(app);app.clickA('stest');
    playSession(app,(i,q)=>{const lv=q&&q._tb!=null?app.T.TB[q._tb].lv:2;return Math.random()<p[lv-1]});
    c[app.T.S.test.lv]++}
  out[name]=Object.fromEntries(Object.entries(c).map(([k,v])=>[['','A1','A2','B1','B2'][k],Math.round(v/N*100)+'%']))}
console.log(out);
