/* Mini DOM para ejecutar la app en Node sin navegador (parser HTML tolerante + selectores básicos + eventos con burbujeo) */
const vm=require('vm');
const ENT={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&#39;':"'",'&nbsp;':' ','&apos;':"'"};
const dec=s=>s.replace(/&(amp|lt|gt|quot|apos|nbsp|#39);/g,m=>ENT[m]);
const enc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const VOID=new Set(['input','br','img','hr','meta','link']);
class T{constructor(t){this.text=t;this.parent=null}}
class El{
  constructor(tag){this.tag=String(tag).toLowerCase();this.attrs={};this.children=[];this.parent=null;this.L={};this._v=undefined}
  get id(){return this.attrs.id||''}set id(v){this.attrs.id=v}
  get className(){return this.attrs.class||''}set className(v){this.attrs.class=v}
  get classList(){const el=this,g=()=>(el.attrs.class||'').split(/\s+/).filter(Boolean);
    return{add(...c){const s=new Set(g());c.forEach(x=>s.add(x));el.attrs.class=[...s].join(' ')},remove(...c){el.attrs.class=g().filter(x=>!c.includes(x)).join(' ')},contains(c){return g().includes(c)},
      toggle(c,f){const has=g().includes(c),w=f===undefined?!has:!!f;if(w&&!has)this.add(c);if(!w&&has)this.remove(c);return w}}}
  get dataset(){const a=this.attrs;return new Proxy({}, {get:(_,k)=>a['data-'+String(k).replace(/[A-Z]/g,m=>'-'+m.toLowerCase())]})}
  get hidden(){return 'hidden' in this.attrs}set hidden(v){if(v)this.attrs.hidden='';else delete this.attrs.hidden}
  get disabled(){return 'disabled' in this.attrs}set disabled(v){if(v)this.attrs.disabled='';else delete this.attrs.disabled}
  get value(){if(this._v!==undefined)return this._v;if(this.tag==='textarea')return this.textContent;return this.attrs.value||''}set value(v){this._v=String(v)}
  get href(){return this.attrs.href}
  get textContent(){return this.children.map(c=>c instanceof T?c.text:c.textContent).join('')}
  set textContent(v){this.children=[];const t=new T(String(v));t.parent=this;this.children.push(t)}
  get innerHTML(){return this.children.map(c=>c instanceof T?enc(c.text):c.outerHTML).join('')}
  set innerHTML(h){this.children=[];parseInto(this,String(h))}
  get outerHTML(){const a=Object.keys(this.attrs).map(k=>' '+k+'="'+String(this.attrs[k]).replace(/"/g,'&quot;')+'"').join('');return '<'+this.tag+a+'>'+(VOID.has(this.tag)?'':this.innerHTML+'</'+this.tag+'>')}
  setAttribute(k,v){this.attrs[k]=String(v)}getAttribute(k){return k in this.attrs?this.attrs[k]:null}hasAttribute(k){return k in this.attrs}removeAttribute(k){delete this.attrs[k]}
  appendChild(c){if(c.parent)c.remove();c.parent=this;this.children.push(c);return c}
  remove(){if(!this.parent)return;const i=this.parent.children.indexOf(this);if(i>=0)this.parent.children.splice(i,1);this.parent=null}
  focus(){}select(){}scrollIntoView(){}
  addEventListener(t,f){(this.L[t]=this.L[t]||[]).push(f)}
  querySelectorAll(sel){const out=[];const parts=sel.trim().split(/\s+/);const walk=(n)=>{n.children.forEach(c=>{if(c instanceof El){if(matchPath(c,parts,this))out.push(c);walk(c)}})};walk(this);return out}
  querySelector(sel){return this.querySelectorAll(sel)[0]||null}
  closest(sel){const parts=sel.trim().split(/\s+/);for(let n=this;n&&n instanceof El;n=n.parent){if(matchPath(n,parts,null))return n}return null}
  matches(sel){return compound(this,sel.trim())}
}
function compound(el,s){const re=/(^[a-z0-9]+)|(#[\w-]+)|(\.[\w-]+)|(\[[^\]]+\])/gi;let m,ok=true,any=false;
  while((m=re.exec(s))){any=true;const x=m[0];
    if(m[1]){if(el.tag!==x.toLowerCase())ok=false}
    else if(x[0]==='#'){if(el.id!==x.slice(1))ok=false}
    else if(x[0]==='.'){if(!el.classList.contains(x.slice(1)))ok=false}
    else{const mm=x.match(/^\[([\w-]+)(?:="?([^"\]]*)"?)?\]$/);if(!mm||!(mm[1] in el.attrs)||(mm[2]!==undefined&&el.attrs[mm[1]]!==mm[2]))ok=false}}
  return any&&ok}
function matchPath(el,parts,root){if(!compound(el,parts[parts.length-1]))return false;let n=el.parent,i=parts.length-2;
  while(i>=0){while(n&&n instanceof El&&!compound(n,parts[i]))n=n.parent;if(!n||!(n instanceof El))return false;n=n.parent;i--}return true}
function parseInto(root,html){const stack=[root];const re=/<!--[\s\S]*?-->|<\/([a-zA-Z0-9]+)\s*>|<([a-zA-Z0-9]+)((?:\s+[^\s=>\/]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?)*)\s*(\/?)>|([^<]+|<)/g;let m;
  const top=()=>stack[stack.length-1];
  while((m=re.exec(html))){
    if(m[0].startsWith('<!--'))continue;
    if(m[1]){const t=m[1].toLowerCase();for(let i=stack.length-1;i>0;i--){if(stack[i].tag===t){stack.length=i;break}}continue}
    if(m[2]){const e=new El(m[2]);const ar=/([^\s=>\/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;let a;const as=m[3]||'';
      while((a=ar.exec(as))){e.attrs[a[1]]=dec(a[2]!==undefined?a[2]:a[3]!==undefined?a[3]:a[4]!==undefined?a[4]:'')}
      e.parent=top();top().children.push(e);if(!VOID.has(e.tag)&&!m[4])stack.push(e);continue}
    if(m[5]!==undefined){const t=new T(dec(m[5]));t.parent=top();top().children.push(t)}}}
function makeEnv(fullHtml,store){
  const m=fullHtml.match(/<body[^>]*>([\s\S]*?)<script>/);const body=new El('body');parseInto(body,m[1]);
  const docEl=new El('html');
  const doc={body:body,documentElement:docEl,L:{},
    querySelector:s=>body.querySelector(s),querySelectorAll:s=>body.querySelectorAll(s),createElement:t=>new El(t),
    addEventListener(t,f){(this.L[t]=this.L[t]||[]).push(f)}};
  const spoken=[];const ls={getItem:k=>(k in store)?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}};
  const ss={getVoices:()=>[{name:'Test US',lang:'en-US'}],speak:u=>spoken.push(u.text),cancel(){},onvoiceschanged:null};
  const ctx={document:doc,localStorage:ls,speechSynthesis:ss,SpeechSynthesisUtterance:class{constructor(t){this.text=t}},navigator:{clipboard:{writeText:t=>{ctx.__clip=t;return Promise.resolve()}}},
    matchMedia:()=>({matches:false,addEventListener(){}}),confirm:()=>true,setTimeout,clearTimeout,setInterval,clearInterval,console,Date,Math,JSON,Set,Map,Object,Array,String,Number,Promise,RegExp,Error,parseInt,parseFloat,isNaN,Proxy,
    scrollTo(){},print(){},__spoken:spoken,__errors:[]};
  ctx.window=ctx;vm.createContext(ctx);return{ctx:ctx,doc:doc,body:body,spoken:spoken,store:store}}
function fire(env,el,type,extra){const ev=Object.assign({type:type,target:el,preventDefault(){},key:''},extra||{});
  for(let n=el;n;n=n.parent){(n.L&&n.L[type]||[]).forEach(f=>f(ev))}
  (env.doc.L[type]||[]).forEach(f=>f(ev))}
module.exports={El,T,makeEnv,fire,parseInto};
